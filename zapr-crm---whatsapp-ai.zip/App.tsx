import React, { useState } from 'react';
import { View, Contact } from './types';
import { MOCK_CONTACTS } from './constants';
import { Sidebar } from './components/Sidebar';
import { Dashboard } from './components/Dashboard';
import { ChatInterface } from './components/ChatInterface';
import { ContactList } from './components/ContactList';
import { Settings } from './components/Settings';
import { BulkSender } from './components/BulkSender';
import { Pipeline } from './components/Pipeline';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<View>(View.INBOX);
  
  // Estado centralizado dos contatos para garantir consistência entre as views
  const [contacts, setContacts] = useState<Contact[]>(MOCK_CONTACTS);

  const handleUpdateContact = (id: string, updates: Partial<Contact>) => {
      setContacts(prev => prev.map(c => c.id === id ? { ...c, ...updates } : c));
  };

  const renderContent = () => {
    switch (currentView) {
      case View.DASHBOARD:
        return <Dashboard />;
      case View.INBOX:
        return <ChatInterface contacts={contacts} onUpdateContact={handleUpdateContact} />;
      case View.CONTACTS:
        return <ContactList contacts={contacts} />;
      case View.CAMPAIGNS:
        return <BulkSender contacts={contacts} />;
      case View.PIPELINE:
        return <Pipeline contacts={contacts} onUpdateContact={handleUpdateContact} />;
      case View.SETTINGS:
        return <Settings />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="flex h-screen w-full bg-slate-50 overflow-hidden">
      <Sidebar currentView={currentView} onChangeView={setCurrentView} />
      <main className="flex-1 h-full overflow-hidden relative bg-white lg:rounded-l-3xl shadow-2xl lg:my-2 lg:mr-2 border border-gray-100">
        {renderContent()}
      </main>
    </div>
  );
};

export default App;