
import { WhatsAppConfig } from "../types";

const GRAPH_API_URL = "https://graph.facebook.com/v18.0";

export const getWhatsAppConfig = (): WhatsAppConfig | null => {
  const stored = localStorage.getItem("whatsapp_config");
  return stored ? JSON.parse(stored) : null;
};

export const saveWhatsAppConfig = (config: WhatsAppConfig) => {
  localStorage.setItem("whatsapp_config", JSON.stringify(config));
};

interface SendMessageOptions {
    to: string;
    type: 'text' | 'template';
    content: string | { 
        name: string; 
        language: string; 
        variables?: string[] // Array de strings para substituir {{1}}, {{2}}...
    };
}

export const sendRealWhatsAppMessage = async (
  to: string,
  messageData: string | SendMessageOptions['content'],
  msgType: 'text' | 'template' = 'text'
): Promise<{ success: boolean; error?: string }> => {
  const config = getWhatsAppConfig();

  if (!config || !config.accessToken || !config.phoneNumberId) {
    return { success: false, error: "Credenciais não configuradas" };
  }

  // Remove formatação do telefone (apenas números)
  const cleanPhone = to.replace(/\D/g, "");

  let body: any = {
      messaging_product: "whatsapp",
      recipient_type: "individual",
      to: cleanPhone,
      type: msgType,
  };

  if (msgType === 'text' && typeof messageData === 'string') {
      body.text = { preview_url: false, body: messageData };
  } else if (msgType === 'template' && typeof messageData === 'object') {
      const { name, language, variables } = messageData as any;
      
      const components = [];
      
      // Se tiver variáveis, adiciona ao body
      if (variables && variables.length > 0) {
          components.push({
              type: "body",
              parameters: variables.map((v: string) => ({
                  type: "text",
                  text: v
              }))
          });
      }

      body.template = {
          name: name,
          language: { code: language || "pt_BR" },
          components: components
      };
  }

  try {
    const response = await fetch(
      `${GRAPH_API_URL}/${config.phoneNumberId}/messages`,
      {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${config.accessToken}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify(body),
      }
    );

    const data = await response.json();

    if (!response.ok) {
      console.error("WhatsApp API Error:", data);
      const errorMsg = data.error?.message || "Erro desconhecido na API";
      
      // Tratamento específico para erro comum de Template
      if (errorMsg.includes("template does not exist")) {
          return { success: false, error: "Template não encontrado ou não aprovado na Meta." };
      }
      
      return { success: false, error: errorMsg };
    }

    return { success: true };
  } catch (error: any) {
    console.error("Network Error:", error);
    return { success: false, error: error.message };
  }
};