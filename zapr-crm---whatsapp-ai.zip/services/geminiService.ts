import { GoogleGenAI, Type, Schema } from "@google/genai";
import { Message, BotConfig } from "../types";

// Helper to get safe API key
const getApiKey = (): string => {
  const key = process.env.API_KEY;
  if (!key) {
    console.warn("API_KEY not found in environment variables");
    return "";
  }
  return key;
};

// Singleton instance
let ai: GoogleGenAI | null = null;

const getAI = () => {
  if (!ai) {
    const apiKey = getApiKey();
    if (apiKey) {
      ai = new GoogleGenAI({ apiKey });
    }
  }
  return ai;
};

// --- CONFIGURAÇÃO DO BOT (STORAGE) ---
export const getBotConfig = (): BotConfig => {
  const stored = localStorage.getItem("bot_config");
  if (stored) {
    const parsed = JSON.parse(stored);
    // Garante que o campo useHistoryLearning exista (default true) mesmo em configs antigas
    return {
        ...parsed,
        useHistoryLearning: parsed.useHistoryLearning ?? true
    };
  }
  
  // Default config if nothing saved
  return {
    botName: "Assistente Virtual",
    businessContext: "Você é um assistente útil e educado. Ajude o cliente com suas dúvidas.",
    isActive: false,
    useHistoryLearning: true // Ativado por padrão
  };
};

export const saveBotConfig = (config: BotConfig) => {
  localStorage.setItem("bot_config", JSON.stringify(config));
};

// --- FUNÇÕES DE IA ---

export const generateSmartReply = async (
  conversationHistory: Message[],
  contactName: string
): Promise<string> => {
  const aiClient = getAI();
  if (!aiClient) return "Erro: API Key não configurada.";
  
  const botConfig = getBotConfig();

  const historyText = conversationHistory
    .map((msg) => `${msg.senderId === "me" ? "Atendente" : contactName}: ${msg.content}`)
    .join("\n");

  const prompt = `
    Você é um assistente de CRM útil e profissional.
    
    CONTEXTO DO NEGÓCIO (Considere isso ao sugerir a resposta):
    "${botConfig.businessContext}"

    Com base no seguinte histórico de conversa de WhatsApp, sugira uma resposta curta, educada e direta para o Atendente enviar.
    Mantenha o tom profissional mas amigável (brasileiro).
    
    Histórico:
    ${historyText}
    
    Sugestão de resposta:
  `;

  try {
    const response = await aiClient.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
    });
    return response.text || "Não foi possível gerar uma resposta.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Erro ao conectar com a IA.";
  }
};

export const analyzeConversation = async (
  conversationHistory: Message[],
  contactName: string
) => {
  const aiClient = getAI();
  if (!aiClient) return null;

  const historyText = conversationHistory
    .map((msg) => `${msg.senderId === "me" ? "Atendente" : contactName}: ${msg.content}`)
    .join("\n");

  const prompt = `
    Analise a seguinte conversa de WhatsApp entre um Atendente e o cliente ${contactName}.
    Retorne um JSON com:
    1. sentiment: 'positive', 'neutral', ou 'negative'.
    2. summary: Um resumo de 1 frase do que está sendo discutido.
    3. intent: Qual a intenção do cliente ('sales', 'support', 'inquiry', 'spam').
    
    Histórico:
    ${historyText}
  `;

  const schema: Schema = {
    type: Type.OBJECT,
    properties: {
      sentiment: { type: Type.STRING, enum: ["positive", "neutral", "negative"] },
      summary: { type: Type.STRING },
      intent: { type: Type.STRING, enum: ["sales", "support", "inquiry", "spam"] },
    },
    required: ["sentiment", "summary", "intent"],
  };

  try {
    const response = await aiClient.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: schema,
      },
    });

    const text = response.text;
    if (text) {
      return JSON.parse(text);
    }
    return null;
  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    return null;
  }
};

export const generateTemplate = async (topic: string, tone: string, includeButtons: boolean = false): Promise<string> => {
  const aiClient = getAI();
  if (!aiClient) return "Erro: API Key não configurada.";

  const prompt = `
    Crie um template de mensagem de WhatsApp curto e efetivo.
    Objetivo da mensagem: "${topic}".
    Tom de voz: "${tone}".
    
    Regras:
    1. Use emojis adequados.
    2. Use quebras de linha para facilitar a leitura.
    3. Use a variável {{Nome}} onde o nome do cliente deve entrar.
    4. Não use aspas no início ou fim.
    5. O texto deve estar em Português do Brasil.
    ${includeButtons ? '6. IMPORTANTE: Adicione ao final 2 ou 3 opções de botões "Quick Reply" (Resposta Rápida). Formate-os EXATAMENTE assim: [Botão: Texto]. Exemplo: [Botão: Sim, quero!] [Botão: Não tenho interesse]. Mantenha os textos dos botões curtos (máx 20 caracteres).' : '6. Não inclua botões.'}
  `;

  try {
    const response = await aiClient.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
    });
    return response.text || "Não foi possível gerar o template.";
  } catch (error) {
    console.error("Gemini Template Error:", error);
    return "Erro ao gerar template.";
  }
};

// --- NOVAS FUNÇÕES DE SIMULAÇÃO ---

export const generateCustomerSimulation = async (
  conversationHistory: Message[],
  contactName: string,
  contactProfile: string
): Promise<string> => {
  const aiClient = getAI();
  if (!aiClient) return "Erro IA";

  const historyText = conversationHistory
    .map((msg) => `${msg.senderId === "me" ? "Empresa" : contactName}: ${msg.content}`)
    .join("\n");

  const prompt = `
    Atue como o cliente ${contactName}.
    Perfil do cliente: ${contactProfile}.
    Contexto: Você está conversando no WhatsApp com uma empresa.
    
    Tarefa: Responda a última mensagem do atendente de forma natural, curta e realista (como uma mensagem de zap).
    Pode conter gírias leves ou erros de digitação comuns se o tom permitir.
    Se o atendente fez uma pergunta, responda. Se ofereceu algo, reaja.

    Histórico da conversa:
    ${historyText}

    Sua resposta (apenas o texto da mensagem):
  `;

  try {
    const response = await aiClient.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
    });
    return response.text?.trim() || "...";
  } catch (error) {
    console.error("Simulation Error:", error);
    return "Ok.";
  }
};

/**
 * Helper para extrair exemplos de "bom atendimento" de outros chats
 */
const getLearningExamples = (allMessages: Record<string, Message[]>, currentChatId: string): string => {
    let examples = "";
    let count = 0;

    // Itera sobre todos os chats, exceto o atual
    for (const [chatId, messages] of Object.entries(allMessages)) {
        if (chatId === currentChatId) continue;
        if (messages.length < 2) continue;

        // Pega as ultimas 2 interações para servir de exemplo
        const lastMessages = messages.slice(-4); 
        
        // Verifica se a ultima msg foi do atendente (sinal de resposta dada)
        const lastMsg = lastMessages[lastMessages.length - 1];
        if (lastMsg.senderId === 'me') {
            examples += `\n--- Exemplo de Atendimento Real ${count + 1} ---\n`;
            examples += lastMessages.map(m => `${m.senderId === 'me' ? 'Atendente' : 'Cliente'}: ${m.content}`).join('\n');
            count++;
        }

        if (count >= 3) break; // Aumentado para 3 exemplos
    }

    return examples;
};

export const generateBotAutoResponse = async (
  conversationHistory: Message[],
  contactName: string,
  allMessages?: Record<string, Message[]> // Opcional: passamos todas as mensagens para ele aprender
): Promise<string> => {
  const aiClient = getAI();
  if (!aiClient) return "Erro Bot";
  
  const botConfig = getBotConfig();

  const historyText = conversationHistory
    .map((msg) => `${msg.senderId === "me" ? botConfig.botName : contactName}: ${msg.content}`)
    .join("\n");

  let learningContext = "";
  if (botConfig.useHistoryLearning && allMessages) {
      // Extrai ID do chat atual da primeira mensagem (hack simples)
      const currentChatId = conversationHistory[0]?.chatId;
      const examples = getLearningExamples(allMessages, currentChatId);
      if (examples) {
          learningContext = `
          EXEMPLOS DE ATENDIMENTO REAL (APRENDIZADO FEW-SHOT):
          Abaixo estão exemplos de como o atendente humano respondeu em situações similares. 
          Observe o tom de voz, a formatação, o uso de emojis e a brevidade. Tente imitar este estilo.
          ${examples}
          `;
      }
  }

  const prompt = `
    Você é "${botConfig.botName}", o atendente virtual inteligente desta empresa.
    Sua função é atender o cliente ${contactName} automaticamente no WhatsApp.

    INSTRUÇÕES E CONTEXTO DO NEGÓCIO (SIGA RIGOROSAMENTE):
    "${botConfig.businessContext}"

    ${learningContext}

    Regras Gerais:
    1. Seja educado e prestativo.
    2. Respostas curtas e formatadas para WhatsApp (use quebras de linha).
    3. Se o contexto do negócio não cobrir a pergunta do cliente, diga gentilmente que irá transferir para um humano.
    4. Nunca invente preços ou produtos que não estejam no contexto acima.

    Histórico da conversa atual:
    ${historyText}

    Sua Resposta:
  `;

  try {
    const response = await aiClient.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
    });
    return response.text?.trim() || "Olá, em que posso ajudar?";
  } catch (error) {
    return "Desculpe, não entendi. Vou chamar um humano.";
  }
};