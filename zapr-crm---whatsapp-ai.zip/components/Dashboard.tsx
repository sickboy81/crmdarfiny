import React from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, LineChart, Line } from 'recharts';
import { TrendingUp, Users, MessageSquare, AlertCircle } from 'lucide-react';

const data = [
  { name: 'Seg', messages: 400, leads: 24 },
  { name: 'Ter', messages: 300, leads: 18 },
  { name: 'Qua', messages: 550, leads: 35 },
  { name: 'Qui', messages: 480, leads: 28 },
  { name: 'Sex', messages: 620, leads: 42 },
  { name: 'Sáb', messages: 200, leads: 10 },
  { name: 'Dom', messages: 150, leads: 5 },
];

const StatCard = ({ title, value, change, icon: Icon, color }: any) => (
  <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow">
    <div className="flex justify-between items-start mb-4">
      <div>
        <p className="text-gray-500 text-sm font-medium mb-1">{title}</p>
        <h3 className="text-3xl font-bold text-gray-800">{value}</h3>
      </div>
      <div className={`p-3 rounded-xl ${color} bg-opacity-10`}>
        <Icon size={24} className={color.replace('bg-', 'text-')} />
      </div>
    </div>
    <div className="flex items-center text-sm">
      <span className="text-green-500 font-semibold flex items-center mr-2">
        <TrendingUp size={16} className="mr-1" /> {change}
      </span>
      <span className="text-gray-400">vs. semana passada</span>
    </div>
  </div>
);

export const Dashboard: React.FC = () => {
  return (
    <div className="p-8 h-full overflow-y-auto">
      <header className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Dashboard Geral</h1>
        <p className="text-gray-500">Visão geral do desempenho do atendimento via WhatsApp.</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatCard 
          title="Mensagens Totais" 
          value="2,450" 
          change="+12%" 
          icon={MessageSquare} 
          color="bg-blue-500" 
        />
        <StatCard 
          title="Novos Leads" 
          value="142" 
          change="+5.2%" 
          icon={Users} 
          color="bg-green-500" 
        />
        <StatCard 
          title="Taxa de Resposta" 
          value="98%" 
          change="+1.2%" 
          icon={TrendingUp} 
          color="bg-purple-500" 
        />
        <StatCard 
          title="Tempo Médio" 
          value="2m 30s" 
          change="-15s" 
          icon={AlertCircle} 
          color="bg-orange-500" 
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
          <h3 className="text-lg font-bold text-gray-800 mb-6">Volume de Mensagens</h3>
          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#6B7280'}} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#6B7280'}} />
                <Tooltip 
                  cursor={{fill: '#F3F4F6'}}
                  contentStyle={{borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'}}
                />
                <Bar dataKey="messages" fill="#3B82F6" radius={[4, 4, 0, 0]} barSize={40} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
          <h3 className="text-lg font-bold text-gray-800 mb-6">Novos Leads</h3>
          <div className="h-80 w-full">
             <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#6B7280'}} dy={10} />
                <Tooltip 
                  contentStyle={{borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'}}
                />
                <Line type="monotone" dataKey="leads" stroke="#10B981" strokeWidth={3} dot={{r: 4, fill: '#10B981'}} activeDot={{r: 6}} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};