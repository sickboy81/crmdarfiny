import React from 'react';
import { Contact } from '../types';
import { PIPELINE_STAGES } from '../constants';
import { MoreHorizontal, Plus, DollarSign, Calendar, ArrowRight, ArrowLeft } from 'lucide-react';
import clsx from 'clsx';

interface PipelineProps {
    contacts: Contact[];
    onUpdateContact: (id: string, updates: Partial<Contact>) => void;
}

export const Pipeline: React.FC<PipelineProps> = ({ contacts, onUpdateContact }) => {
    
    const getColumnTotal = (stageId: string) => {
        return contacts
            .filter(c => (c.pipelineStage || 'new') === stageId)
            .reduce((acc, curr) => acc + (curr.dealValue || 0), 0);
    };

    const getColumnCount = (stageId: string) => {
        return contacts.filter(c => (c.pipelineStage || 'new') === stageId).length;
    };

    const moveCard = (contactId: string, direction: 'next' | 'prev') => {
        const contact = contacts.find(c => c.id === contactId);
        if (!contact) return;

        const currentStage = contact.pipelineStage || 'new';
        const currentIndex = PIPELINE_STAGES.findIndex(s => s.id === currentStage);
        let newIndex = direction === 'next' ? currentIndex + 1 : currentIndex - 1;

        // Bounds check
        if (newIndex < 0) newIndex = 0;
        if (newIndex >= PIPELINE_STAGES.length) newIndex = PIPELINE_STAGES.length - 1;

        onUpdateContact(contactId, { pipelineStage: PIPELINE_STAGES[newIndex].id });
    };

    const formatCurrency = (value: number) => {
        return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
    };

    return (
        <div className="flex flex-col h-full bg-[#f4f5f7] overflow-hidden">
            {/* Header */}
            <div className="px-8 py-6 border-b border-gray-200 bg-white flex justify-between items-center">
                <div>
                    <h1 className="text-2xl font-bold text-gray-900">Pipeline de Vendas</h1>
                    <p className="text-gray-500">Gerencie suas oportunidades e previsão de vendas.</p>
                </div>
                <div className="flex items-center gap-4">
                     <div className="bg-green-50 px-4 py-2 rounded-lg border border-green-100">
                         <span className="text-xs text-green-600 font-bold uppercase block">Total em Pipeline</span>
                         <span className="text-xl font-bold text-green-700">
                             {formatCurrency(contacts.reduce((acc, c) => acc + (c.dealValue || 0), 0))}
                         </span>
                     </div>
                     <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 shadow-sm">
                        <Plus size={18} />
                        Nova Oportunidade
                    </button>
                </div>
            </div>

            {/* Board */}
            <div className="flex-1 overflow-x-auto overflow-y-hidden">
                <div className="h-full flex p-6 gap-6 min-w-max">
                    {PIPELINE_STAGES.map(stage => (
                        <div key={stage.id} className="w-80 flex flex-col h-full rounded-xl bg-gray-100/50 border border-gray-200/60">
                            {/* Column Header */}
                            <div className="p-4 border-b border-gray-200 bg-white/50 backdrop-blur-sm rounded-t-xl">
                                <div className="flex items-center justify-between mb-2">
                                    <div className="flex items-center gap-2">
                                        <div className={`w-3 h-3 rounded-full ${stage.color}`}></div>
                                        <h3 className="font-bold text-gray-700">{stage.label}</h3>
                                    </div>
                                    <span className="bg-gray-200 text-gray-600 text-xs px-2 py-0.5 rounded-full font-bold">
                                        {getColumnCount(stage.id)}
                                    </span>
                                </div>
                                <div className="text-sm font-semibold text-gray-500">
                                    {formatCurrency(getColumnTotal(stage.id))}
                                </div>
                            </div>

                            {/* Column Content */}
                            <div className="flex-1 p-3 overflow-y-auto space-y-3 scrollbar-hide">
                                {contacts
                                    .filter(c => (c.pipelineStage || 'new') === stage.id)
                                    .map(contact => (
                                        <div key={contact.id} className="bg-white p-4 rounded-lg shadow-sm border border-gray-100 hover:shadow-md transition-shadow group relative">
                                            <div className="flex justify-between items-start mb-2">
                                                <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">{contact.company || 'Particular'}</span>
                                                <button className="text-gray-300 hover:text-gray-600">
                                                    <MoreHorizontal size={16} />
                                                </button>
                                            </div>
                                            
                                            <h4 className="font-bold text-gray-800 mb-1">{contact.name}</h4>
                                            
                                            <div className="flex items-center gap-1 text-green-600 font-semibold text-sm mb-3">
                                                <DollarSign size={14} />
                                                {formatCurrency(contact.dealValue || 0)}
                                            </div>

                                            <div className="flex flex-wrap gap-1 mb-3">
                                                {contact.tags.slice(0, 2).map(tag => (
                                                    <span key={tag} className="text-[10px] bg-gray-50 text-gray-500 px-1.5 py-0.5 rounded border border-gray-100">
                                                        {tag}
                                                    </span>
                                                ))}
                                            </div>

                                            <div className="flex items-center justify-between pt-3 border-t border-gray-50 mt-3">
                                                <div className="flex items-center gap-2 text-xs text-gray-400">
                                                    <img src={contact.avatar} className="w-6 h-6 rounded-full" alt="" />
                                                    <Calendar size={12} /> 2d
                                                </div>
                                                
                                                {/* Move Actions */}
                                                <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity absolute bottom-3 right-3 bg-white pl-2">
                                                    {stage.id !== 'new' && (
                                                        <button 
                                                            onClick={() => moveCard(contact.id, 'prev')}
                                                            className="p-1 hover:bg-gray-100 rounded text-gray-500" 
                                                            title="Voltar estágio"
                                                        >
                                                            <ArrowLeft size={16} />
                                                        </button>
                                                    )}
                                                    {stage.id !== 'lost' && (
                                                        <button 
                                                            onClick={() => moveCard(contact.id, 'next')}
                                                            className="p-1 hover:bg-gray-100 rounded text-gray-500"
                                                            title="Avançar estágio"
                                                        >
                                                            <ArrowRight size={16} />
                                                        </button>
                                                    )}
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                            </div>
                            
                            {/* Column Footer */}
                            <button className="m-3 p-2 border border-dashed border-gray-300 rounded-lg text-gray-400 text-sm hover:bg-gray-50 hover:text-gray-600 transition-colors flex items-center justify-center gap-2">
                                <Plus size={16} /> Adicionar
                            </button>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};