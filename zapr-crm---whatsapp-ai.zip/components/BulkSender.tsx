import React, { useState, useMemo, useEffect, useRef } from 'react';
import { Contact } from '../types';
import { Megaphone, Search, CheckSquare, Square, Send, CheckCircle2, Play, Pause, RefreshCw, Clock, Settings2, ShieldCheck, XCircle } from 'lucide-react';
import { sendRealWhatsAppMessage } from '../services/whatsappService';
import clsx from 'clsx';

interface BulkSenderProps {
    contacts: Contact[];
}

interface CampaignLog {
    id: string;
    contactName: string;
    phone: string;
    status: 'pending' | 'sending' | 'success' | 'failed';
    error?: string;
    timestamp?: string;
}

export const BulkSender: React.FC<BulkSenderProps> = ({ contacts }) => {
    // Stage: 'selection' | 'config' | 'running'
    const [stage, setStage] = useState<'selection' | 'config' | 'running'>('selection');
    
    // --- Selection State ---
    const [selectedContactIds, setSelectedContactIds] = useState<string[]>([]);
    const [filterTag, setFilterTag] = useState<string>('Todos');
    const [searchTerm, setSearchTerm] = useState('');

    // --- Configuration State (Templates & Safety) ---
    const [templateName, setTemplateName] = useState('hello_world');
    const [templateLang, setTemplateLang] = useState('pt_BR');
    const [variable1, setVariable1] = useState('{{nome}}'); // Variable mapping
    
    // Safety Settings
    const [delaySeconds, setDelaySeconds] = useState(15); // Default 15s delay
    const [isPaused, setIsPaused] = useState(true);

    // --- Execution State ---
    const [queue, setQueue] = useState<CampaignLog[]>([]);
    const [currentIndex, setCurrentIndex] = useState(0);
    const [completedCount, setCompletedCount] = useState(0);
    const [successCount, setSuccessCount] = useState(0);
    const [failedCount, setFailedCount] = useState(0);

    const processingRef = useRef<boolean>(false);
    const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

    // Filter Logic
    const availableTags = useMemo(() => {
        const tags = new Set<string>(['Todos']);
        contacts.forEach(c => c.tags.forEach(t => tags.add(t)));
        return Array.from(tags);
    }, [contacts]);

    const filteredContacts = contacts.filter(contact => {
        const matchesTag = filterTag === 'Todos' || contact.tags.includes(filterTag);
        const matchesSearch = contact.name.toLowerCase().includes(searchTerm.toLowerCase());
        return matchesTag && matchesSearch;
    });

    // --- Handlers: Selection ---
    const toggleContact = (id: string) => {
        setSelectedContactIds(prev => 
            prev.includes(id) ? prev.filter(c => c !== id) : [...prev, id]
        );
    };

    const toggleAll = () => {
        if (selectedContactIds.length === filteredContacts.length) {
            setSelectedContactIds([]);
        } else {
            setSelectedContactIds(filteredContacts.map(c => c.id));
        }
    };

    // --- Handlers: Campaign Logic ---
    const prepareCampaign = () => {
        // Create initial queue
        const targets = contacts.filter(c => selectedContactIds.includes(c.id));
        const initialQueue: CampaignLog[] = targets.map(c => ({
            id: c.id,
            contactName: c.name,
            phone: c.phoneNumber,
            status: 'pending'
        }));
        
        setQueue(initialQueue);
        setCurrentIndex(0);
        setCompletedCount(0);
        setSuccessCount(0);
        setFailedCount(0);
        setStage('running');
        setIsPaused(true); // Start paused so user can hit play
    };

    const processNextMessage = async () => {
        if (currentIndex >= queue.length) {
            setIsPaused(true);
            return;
        }

        const currentItem = queue[currentIndex];
        
        // Mark as sending
        setQueue(prev => prev.map((item, idx) => idx === currentIndex ? { ...item, status: 'sending' } : item));

        // Prepare Variables
        const vars: string[] = [];
        if (variable1) {
            // Replace {{nome}} with actual first name
            let val = variable1.replace('{{nome}}', currentItem.contactName.split(' ')[0]);
            vars.push(val);
        }

        // Send Real API Request
        const result = await sendRealWhatsAppMessage(
            currentItem.phone,
            {
                name: templateName,
                language: templateLang,
                variables: vars
            },
            'template'
        );

        // Update Status
        const now = new Date().toLocaleTimeString();
        setQueue(prev => prev.map((item, idx) => idx === currentIndex ? { 
            ...item, 
            status: result.success ? 'success' : 'failed',
            error: result.error,
            timestamp: now
        } : item));

        if (result.success) setSuccessCount(p => p + 1);
        else setFailedCount(p => p + 1);

        setCompletedCount(p => p + 1);
        setCurrentIndex(p => p + 1);
    };

    // --- The Heartbeat: Effect that controls the queue ---
    useEffect(() => {
        if (stage !== 'running') return;

        if (!isPaused && currentIndex < queue.length) {
            // If just started or just finished previous, schedule next
            if (!processingRef.current) {
                processingRef.current = true;
                timerRef.current = setTimeout(async () => {
                    await processNextMessage();
                    processingRef.current = false;
                }, delaySeconds * 1000);
            }
        } else {
            // Cleanup if paused
            if (timerRef.current) {
                clearTimeout(timerRef.current);
                timerRef.current = null;
                processingRef.current = false;
            }
        }

        return () => {
            if (timerRef.current) clearTimeout(timerRef.current);
        };
    }, [isPaused, currentIndex, stage, queue]); // Dependencies control the loop

    // Estimated Time
    const remainingMessages = queue.length - completedCount;
    const estimatedSeconds = remainingMessages * delaySeconds;
    const estimatedTime = estimatedSeconds > 60 
        ? `${Math.floor(estimatedSeconds / 60)} min ${estimatedSeconds % 60} seg` 
        : `${estimatedSeconds} seg`;

    return (
        <div className="flex h-full bg-gray-50">
            {/* Left Panel: Configuration & Steps */}
            <div className="w-1/3 bg-white border-r border-gray-200 flex flex-col p-6 shadow-xl z-10">
                <div className="mb-8">
                    <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
                        <Megaphone className="text-green-600" /> Disparador Pro
                    </h1>
                    <p className="text-gray-500 mt-2 text-sm">Envio em massa seguro via API Oficial.</p>
                </div>

                {/* Stepper */}
                <div className="space-y-6 mb-8">
                    <div className={clsx("flex items-center gap-4 transition-all", stage === 'selection' ? "text-green-600 font-bold" : "text-gray-400")}>
                        <div className={clsx("w-8 h-8 rounded-full flex items-center justify-center border-2", stage === 'selection' ? "border-green-600 bg-green-50" : "border-gray-200")}>1</div>
                        <span>Selecionar Audiência</span>
                    </div>
                    <div className="w-0.5 h-6 bg-gray-200 ml-4"></div>
                    <div className={clsx("flex items-center gap-4 transition-all", stage === 'config' ? "text-green-600 font-bold" : "text-gray-400")}>
                        <div className={clsx("w-8 h-8 rounded-full flex items-center justify-center border-2", stage === 'config' ? "border-green-600 bg-green-50" : "border-gray-200")}>2</div>
                        <span>Configurar & Segurança</span>
                    </div>
                    <div className="w-0.5 h-6 bg-gray-200 ml-4"></div>
                    <div className={clsx("flex items-center gap-4 transition-all", stage === 'running' ? "text-green-600 font-bold" : "text-gray-400")}>
                        <div className={clsx("w-8 h-8 rounded-full flex items-center justify-center border-2", stage === 'running' ? "border-green-600 bg-green-50" : "border-gray-200")}>3</div>
                        <span>Monitoramento</span>
                    </div>
                </div>

                {stage === 'running' && (
                    <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-4">
                        <div className="flex justify-between items-center">
                            <span className="text-sm font-bold text-gray-700">Status da Fila</span>
                            <span className={clsx("px-2 py-1 rounded text-xs font-bold uppercase", isPaused ? "bg-yellow-100 text-yellow-700" : "bg-green-100 text-green-700")}>
                                {isPaused ? "Pausado" : "Rodando"}
                            </span>
                        </div>
                        
                        <div className="flex gap-2">
                             <button 
                                onClick={() => setIsPaused(!isPaused)}
                                className={clsx("flex-1 py-2 rounded-lg font-bold flex items-center justify-center gap-2 transition-colors", 
                                    isPaused 
                                        ? "bg-green-600 hover:bg-green-700 text-white" 
                                        : "bg-yellow-500 hover:bg-yellow-600 text-white"
                                )}
                            >
                                {isPaused ? (
                                    <>
                                        <Play size={18} /> Iniciar/Retomar
                                    </>
                                ) : (
                                    <>
                                        <Pause size={18} /> Pausar Envio
                                    </>
                                )}
                            </button>
                        </div>

                        <div className="grid grid-cols-2 gap-2 text-center">
                            <div className="bg-white p-2 rounded border border-gray-200">
                                <div className="text-xs text-gray-500">Estimativa</div>
                                <div className="font-mono font-bold text-gray-800">{estimatedTime}</div>
                            </div>
                            <div className="bg-white p-2 rounded border border-gray-200">
                                <div className="text-xs text-gray-500">Delay Atual</div>
                                <div className="font-mono font-bold text-gray-800">{delaySeconds}s</div>
                            </div>
                        </div>
                    </div>
                )}
                
                {stage === 'running' && currentIndex >= queue.length && queue.length > 0 && (
                    <div className="mt-4">
                         <button 
                            onClick={() => {
                                setStage('selection');
                                setQueue([]);
                            }}
                            className="w-full py-3 bg-gray-800 hover:bg-gray-900 text-white rounded-xl font-bold flex items-center justify-center gap-2"
                        >
                            <RefreshCw size={18} /> Nova Campanha
                        </button>
                    </div>
                )}

                <div className="mt-auto">
                    <div className="bg-blue-50 p-4 rounded-xl border border-blue-100 text-sm text-blue-800">
                        <div className="flex items-center gap-2 font-bold mb-2">
                            <ShieldCheck size={16} /> Proteção Ativa
                        </div>
                        <p className="opacity-90">O sistema força um intervalo entre mensagens para evitar bloqueios do WhatsApp. Não feche esta aba.</p>
                    </div>
                </div>
            </div>

            {/* Right Panel: Content */}
            <div className="flex-1 p-8 overflow-y-auto relative">
                
                {/* STAGE 1: SELECTION */}
                {stage === 'selection' && (
                    <div className="max-w-4xl mx-auto animate-in fade-in slide-in-from-right-4">
                         <div className="flex justify-between items-center mb-6">
                            <h2 className="text-xl font-bold text-gray-800">1. Selecione a Audiência</h2>
                            <span className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-bold">
                                {selectedContactIds.length} contatos
                            </span>
                        </div>

                         {/* Filters */}
                         <div className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm mb-6 space-y-4">
                            <div className="flex gap-2 overflow-x-auto pb-2">
                                {availableTags.map(tag => (
                                    <button
                                        key={tag}
                                        onClick={() => setFilterTag(tag)}
                                        className={clsx(
                                            "px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-colors",
                                            filterTag === tag 
                                                ? "bg-green-600 text-white" 
                                                : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                                        )}
                                    >
                                        {tag}
                                    </button>
                                ))}
                            </div>
                            <div className="relative">
                                <Search className="absolute left-3 top-3 text-gray-400" size={18} />
                                <input 
                                    type="text" 
                                    placeholder="Buscar por nome..." 
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                    className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-green-500 outline-none"
                                />
                            </div>
                        </div>

                         {/* List */}
                         <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden mb-6">
                            <div className="p-3 border-b border-gray-100 bg-gray-50 flex items-center gap-3">
                                <button onClick={toggleAll} className="text-gray-500 hover:text-gray-700">
                                    {selectedContactIds.length === filteredContacts.length && filteredContacts.length > 0
                                        ? <CheckSquare className="text-green-600" />
                                        : <Square />
                                    }
                                </button>
                                <span className="text-sm font-semibold text-gray-600">Selecionar Todos</span>
                            </div>
                            <div className="max-h-[400px] overflow-y-auto divide-y divide-gray-100">
                                {filteredContacts.map(contact => (
                                    <div 
                                        key={contact.id} 
                                        className={clsx(
                                            "flex items-center gap-3 p-4 hover:bg-gray-50 cursor-pointer transition-colors",
                                            selectedContactIds.includes(contact.id) ? "bg-green-50/50" : ""
                                        )}
                                        onClick={() => toggleContact(contact.id)}
                                    >
                                        <div className={selectedContactIds.includes(contact.id) ? "text-green-600" : "text-gray-300"}>
                                            {selectedContactIds.includes(contact.id) ? <CheckSquare /> : <Square />}
                                        </div>
                                        <div className="flex-1">
                                            <p className="font-semibold text-gray-800">{contact.name}</p>
                                            <p className="text-xs text-gray-500">{contact.phoneNumber}</p>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>

                        <div className="flex justify-end">
                            <button 
                                onClick={() => setStage('config')}
                                disabled={selectedContactIds.length === 0}
                                className="bg-green-600 hover:bg-green-700 disabled:bg-gray-300 text-white px-8 py-3 rounded-xl font-bold shadow-lg shadow-green-900/10 flex items-center gap-2"
                            >
                                Continuar
                            </button>
                        </div>
                    </div>
                )}

                {/* STAGE 2: CONFIGURATION */}
                {stage === 'config' && (
                    <div className="max-w-4xl mx-auto animate-in fade-in slide-in-from-right-4">
                        <div className="flex items-center justify-between mb-6">
                            <h2 className="text-xl font-bold text-gray-800">2. Configuração do Template e Velocidade</h2>
                            <button onClick={() => setStage('selection')} className="text-gray-500 hover:text-gray-700 underline text-sm">Voltar</button>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                            {/* Template Config */}
                            <div className="space-y-6">
                                <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
                                    <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
                                        <Settings2 size={18} className="text-blue-600" /> Dados do Template
                                    </h3>
                                    
                                    <div className="space-y-4">
                                        <div>
                                            <label className="block text-sm font-medium text-gray-700 mb-1">Nome do Template (Meta)</label>
                                            <input 
                                                type="text" 
                                                value={templateName} 
                                                onChange={e => setTemplateName(e.target.value)}
                                                placeholder="Ex: hello_world, black_friday_offer"
                                                className="w-full p-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-green-500 outline-none"
                                            />
                                            <p className="text-xs text-gray-500 mt-1">Deve ser idêntico ao cadastrado no Gerenciador do WhatsApp.</p>
                                        </div>

                                        <div className="grid grid-cols-2 gap-4">
                                            <div>
                                                <label className="block text-sm font-medium text-gray-700 mb-1">Idioma</label>
                                                <input 
                                                    type="text" 
                                                    value={templateLang} 
                                                    onChange={e => setTemplateLang(e.target.value)}
                                                    className="w-full p-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-green-500 outline-none"
                                                />
                                            </div>
                                            <div>
                                                <label className="block text-sm font-medium text-gray-700 mb-1">Variável 1 ({{1}})</label>
                                                <input 
                                                    type="text" 
                                                    value={variable1} 
                                                    onChange={e => setVariable1(e.target.value)}
                                                    className="w-full p-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-green-500 outline-none"
                                                />
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div className="bg-yellow-50 p-4 rounded-xl border border-yellow-100 text-sm text-yellow-800">
                                    <strong className="block mb-1">⚠️ Aviso Importante</strong>
                                    A API Oficial do WhatsApp <strong>não permite</strong> enviar texto livre como primeira mensagem. Você deve usar um template aprovado. Se o template não existir na sua conta, o envio falhará.
                                </div>
                            </div>

                            {/* Speed Config */}
                            <div className="space-y-6">
                                <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
                                    <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
                                        <Clock size={18} className="text-orange-600" /> Velocidade de Disparo
                                    </h3>

                                    <div className="space-y-6">
                                        <div>
                                            <div className="flex justify-between mb-2">
                                                <label className="text-sm font-medium text-gray-700">Intervalo entre mensagens</label>
                                                <span className="text-sm font-bold text-orange-600">{delaySeconds} segundos</span>
                                            </div>
                                            <input 
                                                type="range" 
                                                min="5" 
                                                max="120" 
                                                step="5"
                                                value={delaySeconds}
                                                onChange={e => setDelaySeconds(Number(e.target.value))}
                                                className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-orange-600"
                                            />
                                            <div className="flex justify-between text-xs text-gray-400 mt-1">
                                                <span>Rápido (Risco Médio)</span>
                                                <span>Seguro (Recomendado)</span>
                                                <span>Lento (Muito Seguro)</span>
                                            </div>
                                        </div>

                                        <div className="bg-gray-50 p-3 rounded-lg border border-gray-200">
                                            <p className="text-xs text-gray-600">
                                                Com <strong>{selectedContactIds.length} contatos</strong> e intervalo de <strong>{delaySeconds}s</strong>, 
                                                a campanha levará aproximadamente:
                                            </p>
                                            <p className="text-lg font-bold text-gray-800 mt-1">
                                                {Math.ceil((selectedContactIds.length * delaySeconds) / 60)} minutos
                                            </p>
                                        </div>
                                    </div>
                                </div>

                                <div className="flex justify-end">
                                    <button 
                                        onClick={prepareCampaign}
                                        disabled={!templateName}
                                        className="w-full bg-green-600 hover:bg-green-700 disabled:bg-gray-300 text-white px-8 py-4 rounded-xl font-bold shadow-lg shadow-green-900/10 flex items-center justify-center gap-2 text-lg"
                                    >
                                        <Send size={20} />
                                        Preparar Envio
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                )}

                {/* STAGE 3: RUNNING */}
                {stage === 'running' && (
                     <div className="max-w-5xl mx-auto animate-in fade-in slide-in-from-right-4 h-full flex flex-col">
                        <div className="grid grid-cols-3 gap-4 mb-6">
                            <div className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm flex flex-col items-center">
                                <span className="text-gray-500 text-xs font-bold uppercase">Total Enviado</span>
                                <span className="text-3xl font-bold text-blue-600">{completedCount} <span className="text-base text-gray-400">/ {queue.length}</span></span>
                            </div>
                            <div className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm flex flex-col items-center">
                                <span className="text-gray-500 text-xs font-bold uppercase">Sucessos</span>
                                <span className="text-3xl font-bold text-green-600">{successCount}</span>
                            </div>
                            <div className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm flex flex-col items-center">
                                <span className="text-gray-500 text-xs font-bold uppercase">Falhas</span>
                                <span className="text-3xl font-bold text-red-600">{failedCount}</span>
                            </div>
                        </div>

                        {/* Progress Bar */}
                        <div className="w-full bg-gray-200 rounded-full h-4 mb-6 overflow-hidden">
                            <div 
                                className="bg-green-500 h-4 transition-all duration-500 ease-out"
                                style={{ width: `${(completedCount / queue.length) * 100}%` }}
                            />
                        </div>

                        {/* Detailed Log Table */}
                        <div className="flex-1 bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden flex flex-col">
                            <div className="p-4 border-b border-gray-100 bg-gray-50 font-bold text-gray-700 flex justify-between items-center">
                                <span>Log em Tempo Real</span>
                                <span className="text-xs font-normal text-gray-500">Atualizado automaticamente</span>
                            </div>
                            
                            <div className="flex-1 overflow-y-auto p-0">
                                <table className="w-full text-left text-sm">
                                    <thead className="bg-gray-50 text-gray-500 sticky top-0">
                                        <tr>
                                            <th className="p-3 font-medium">Nome</th>
                                            <th className="p-3 font-medium">Telefone</th>
                                            <th className="p-3 font-medium">Horário</th>
                                            <th className="p-3 font-medium text-right">Status</th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-gray-100">
                                        {queue.map((item, idx) => (
                                            <tr key={idx} className={clsx(
                                                "transition-colors",
                                                idx === currentIndex ? "bg-blue-50" : "hover:bg-gray-50"
                                            )}>
                                                <td className="p-3 font-medium text-gray-800">{item.contactName}</td>
                                                <td className="p-3 text-gray-500">{item.phone}</td>
                                                <td className="p-3 text-gray-500">{item.timestamp || '-'}</td>
                                                <td className="p-3 text-right">
                                                    {item.status === 'pending' && <span className="text-gray-400 px-2 py-1 bg-gray-100 rounded text-xs">Aguardando</span>}
                                                    {item.status === 'sending' && <span className="text-blue-600 px-2 py-1 bg-blue-100 rounded text-xs animate-pulse font-bold">Enviando...</span>}
                                                    {item.status === 'success' && <span className="text-green-700 px-2 py-1 bg-green-100 rounded text-xs font-bold flex items-center gap-1 justify-end ml-auto w-fit"><CheckCircle2 size={12}/> Sucesso</span>}
                                                    {item.status === 'failed' && (
                                                        <div className="flex flex-col items-end">
                                                            <span className="text-red-700 px-2 py-1 bg-red-100 rounded text-xs font-bold flex items-center gap-1 w-fit"><XCircle size={12}/> Falha</span>
                                                            <span className="text-[10px] text-red-500 mt-1 max-w-[150px] truncate" title={item.error}>{item.error}</span>
                                                        </div>
                                                    )}
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                     </div>
                )}
            </div>
        </div>
    );
};