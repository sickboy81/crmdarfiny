import React, { useState, useEffect } from 'react';
import { Save, AlertTriangle, CheckCircle, Shield, Bot, MessageSquare, BrainCircuit, Sparkles, Database, Settings as SettingsIcon, Tag, Download, Upload, Trash2, Plus, Bell, Moon, Sun } from 'lucide-react';
import { getWhatsAppConfig, saveWhatsAppConfig } from '../services/whatsappService';
import { getBotConfig, saveBotConfig } from '../services/geminiService';
import { WhatsAppConfig, BotConfig } from '../types';
import clsx from 'clsx';

export const Settings: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'whatsapp' | 'ai' | 'general'>('ai');
  
  // WhatsApp State
  const [waConfig, setWaConfig] = useState<WhatsAppConfig>({
    accessToken: '',
    phoneNumberId: '',
    businessAccountId: ''
  });
  
  // Bot State
  const [botConfig, setBotConfig] = useState<BotConfig>({
    botName: '',
    businessContext: '',
    isActive: false,
    useHistoryLearning: false
  });

  // General State
  const [crmTags, setCrmTags] = useState<string[]>(['Cliente VIP', 'Lead Quente', 'Novo Lead', 'Ex-Cliente', 'Suporte']);
  const [newTag, setNewTag] = useState('');
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);

  const [status, setStatus] = useState<'idle' | 'success' | 'error'>('idle');

  useEffect(() => {
    // Load both configs
    const savedWa = getWhatsAppConfig();
    if (savedWa) setWaConfig(savedWa);

    const savedBot = getBotConfig();
    if (savedBot) setBotConfig(savedBot);

    // Load Tags
    const savedTags = localStorage.getItem('crm_tags');
    if (savedTags) setCrmTags(JSON.parse(savedTags));
  }, []);

  const handleSaveWa = () => {
    if (!waConfig.accessToken || !waConfig.phoneNumberId) {
      setStatus('error');
      return;
    }
    saveWhatsAppConfig(waConfig);
    setStatus('success');
    setTimeout(() => setStatus('idle'), 3000);
  };

  const handleSaveBot = () => {
    if (!botConfig.botName || !botConfig.businessContext) {
       setStatus('error');
       return;
    }
    saveBotConfig(botConfig);
    setStatus('success');
    setTimeout(() => setStatus('idle'), 3000);
  };

  // --- General Functions ---

  const handleAddTag = () => {
      if (newTag.trim() && !crmTags.includes(newTag.trim())) {
          const updatedTags = [...crmTags, newTag.trim()];
          setCrmTags(updatedTags);
          localStorage.setItem('crm_tags', JSON.stringify(updatedTags));
          setNewTag('');
      }
  };

  const handleRemoveTag = (tagToRemove: string) => {
      const updatedTags = crmTags.filter(t => t !== tagToRemove);
      setCrmTags(updatedTags);
      localStorage.setItem('crm_tags', JSON.stringify(updatedTags));
  };

  const handleExportData = () => {
      const data = {
          waConfig,
          botConfig,
          crmTags,
          timestamp: new Date().toISOString()
      };
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `zapr_backup_${new Date().toISOString().split('T')[0]}.json`;
      a.click();
      URL.revokeObjectURL(url);
      setStatus('success');
      setTimeout(() => setStatus('idle'), 3000);
  };

  const handleImportData = (event: React.ChangeEvent<HTMLInputElement>) => {
      const file = event.target.files?.[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = (e) => {
          try {
              const data = JSON.parse(e.target?.result as string);
              if (data.waConfig) {
                  setWaConfig(data.waConfig);
                  saveWhatsAppConfig(data.waConfig);
              }
              if (data.botConfig) {
                  setBotConfig(data.botConfig);
                  saveBotConfig(data.botConfig);
              }
              if (data.crmTags) {
                  setCrmTags(data.crmTags);
                  localStorage.setItem('crm_tags', JSON.stringify(data.crmTags));
              }
              alert('Dados importados com sucesso!');
              setStatus('success');
          } catch (error) {
              console.error("Import error", error);
              alert('Erro ao importar arquivo. Formato inválido.');
              setStatus('error');
          }
      };
      reader.readAsText(file);
      // Reset input
      event.target.value = '';
  };

  return (
    <div className="flex flex-col h-full bg-gray-50 overflow-hidden">
      {/* Header with Tabs */}
      <div className="bg-white border-b border-gray-200 px-8 py-6">
        <h1 className="text-2xl font-bold text-gray-900 mb-6">Configurações</h1>
        
        <div className="flex gap-6 border-b border-gray-100 overflow-x-auto">
            <button 
                onClick={() => setActiveTab('ai')}
                className={clsx(
                    "pb-3 flex items-center gap-2 font-medium transition-colors border-b-2 whitespace-nowrap",
                    activeTab === 'ai' 
                        ? "border-purple-600 text-purple-700" 
                        : "border-transparent text-gray-500 hover:text-gray-700"
                )}
            >
                <BrainCircuit size={20} />
                Inteligência Artificial
            </button>
            <button 
                onClick={() => setActiveTab('whatsapp')}
                className={clsx(
                    "pb-3 flex items-center gap-2 font-medium transition-colors border-b-2 whitespace-nowrap",
                    activeTab === 'whatsapp' 
                        ? "border-green-600 text-green-700" 
                        : "border-transparent text-gray-500 hover:text-gray-700"
                )}
            >
                <MessageSquare size={20} />
                WhatsApp API
            </button>
            <button 
                onClick={() => setActiveTab('general')}
                className={clsx(
                    "pb-3 flex items-center gap-2 font-medium transition-colors border-b-2 whitespace-nowrap",
                    activeTab === 'general' 
                        ? "border-blue-600 text-blue-700" 
                        : "border-transparent text-gray-500 hover:text-gray-700"
                )}
            >
                <SettingsIcon size={20} />
                Geral e Dados
            </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-8">
        
        {/* --- AI TAB --- */}
        {activeTab === 'ai' && (
             <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 animate-in fade-in slide-in-from-bottom-4 duration-300">
                <div className="space-y-6">
                    <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm space-y-6">
                        <div className="flex justify-between items-center">
                             <h2 className="text-lg font-bold text-gray-800 flex items-center gap-2">
                                <Bot className="text-purple-600" /> Identidade do Bot
                             </h2>
                        </div>

                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">Nome do Assistente</label>
                            <input
                            type="text"
                            value={botConfig.botName}
                            onChange={(e) => setBotConfig({ ...botConfig, botName: e.target.value })}
                            placeholder="Ex: Ana, ZaprBot, Atendente..."
                            className="w-full p-3 bg-white border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 focus:outline-none text-gray-900"
                            />
                        </div>

                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1 flex justify-between">
                                <span>Contexto e Regras do Negócio</span>
                                <span className="text-xs text-purple-600 font-bold bg-purple-50 px-2 py-0.5 rounded-full">O Cérebro do Bot</span>
                            </label>
                            <textarea
                                value={botConfig.businessContext}
                                onChange={(e) => setBotConfig({ ...botConfig, businessContext: e.target.value })}
                                placeholder="Descreva sua empresa aqui. Ex: Somos a Pizzaria Bella. Nossas pizzas custam R$50. Entregamos em 30min. Aceitamos Pix. Se o cliente reclamar, peça desculpas e ofereça cupom..."
                                className="w-full h-64 p-3 bg-white border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 focus:outline-none resize-none text-sm leading-relaxed text-gray-900"
                            />
                            <p className="text-xs text-gray-400 mt-2">
                                Quanto mais detalhes você der aqui, mais inteligente o bot será. Inclua preços, prazos, políticas de reembolso e tom de voz.
                            </p>
                        </div>

                        {/* Learning Toggle */}
                        <div className="flex items-center justify-between p-4 bg-purple-50 rounded-xl border border-purple-100">
                             <div className="flex items-start gap-3">
                                <div className="p-2 bg-white rounded-lg text-purple-600 border border-purple-100">
                                    <Database size={20} />
                                </div>
                                <div>
                                    <h4 className="font-semibold text-gray-800 text-sm">Aprender com Histórico</h4>
                                    <p className="text-xs text-gray-500 mt-0.5">O bot vai ler conversas passadas para imitar seu estilo.</p>
                                </div>
                             </div>
                             
                             <button 
                                onClick={() => setBotConfig({...botConfig, useHistoryLearning: !botConfig.useHistoryLearning})}
                                className={clsx(
                                    "w-12 h-6 rounded-full relative transition-colors duration-300",
                                    botConfig.useHistoryLearning ? "bg-purple-600" : "bg-gray-300"
                                )}
                             >
                                <div className={clsx(
                                    "w-4 h-4 bg-white rounded-full absolute top-1 transition-all duration-300",
                                    botConfig.useHistoryLearning ? "left-7" : "left-1"
                                )} />
                             </button>
                        </div>

                        <button
                            onClick={handleSaveBot}
                            className="w-full bg-purple-600 hover:bg-purple-700 text-white font-bold py-3 rounded-xl flex items-center justify-center gap-2 transition-colors"
                        >
                            {status === 'success' ? <CheckCircle size={20} /> : <Save size={20} />}
                            {status === 'success' ? 'Treinamento Salvo!' : 'Salvar Treinamento'}
                        </button>
                    </div>
                </div>

                <div className="space-y-6">
                    <div className="bg-gradient-to-br from-purple-900 to-indigo-900 text-white p-8 rounded-2xl shadow-lg relative overflow-hidden">
                        <Sparkles className="absolute top-4 right-4 text-purple-400 opacity-50" size={48} />
                        <h3 className="text-xl font-bold mb-4">Dicas de Treinamento</h3>
                        <p className="text-purple-200 text-sm mb-6">
                            Para o Gemini funcionar perfeitamente como seu atendente, tente estruturar o contexto assim:
                        </p>
                        
                        <div className="space-y-4 text-sm bg-white/10 p-4 rounded-xl border border-white/10">
                            <div>
                                <strong className="text-purple-300 block mb-1">1. Quem somos:</strong>
                                "Somos a Zapr, uma consultoria de software."
                            </div>
                            <div>
                                <strong className="text-purple-300 block mb-1">2. O que vendemos:</strong>
                                "Planos Basic (R$100) e Pro (R$200)."
                            </div>
                            <div>
                                <strong className="text-purple-300 block mb-1">3. Regras de Ouro:</strong>
                                "Nunca dê descontos maiores que 10%. Seja sempre formal."
                            </div>
                        </div>
                    </div>
                </div>
             </div>
        )}

        {/* --- WHATSAPP TAB --- */}
        {activeTab === 'whatsapp' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 animate-in fade-in slide-in-from-bottom-4 duration-300">
            <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm space-y-6">
              <div className="flex items-center gap-2 text-green-700 bg-green-50 p-3 rounded-lg border border-green-100 mb-4">
                 <Shield size={20} />
                 <span className="text-sm font-medium">Seus dados são salvos apenas no seu navegador.</span>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Access Token</label>
                <input
                  type="password"
                  value={waConfig.accessToken}
                  onChange={(e) => setWaConfig({ ...waConfig, accessToken: e.target.value })}
                  placeholder="EAA..."
                  className="w-full p-3 bg-white border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 focus:outline-none font-mono text-sm text-gray-900"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Phone Number ID</label>
                <input
                  type="text"
                  value={waConfig.phoneNumberId}
                  onChange={(e) => setWaConfig({ ...waConfig, phoneNumberId: e.target.value })}
                  placeholder="Ex: 1045267..."
                  className="w-full p-3 bg-white border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 focus:outline-none font-mono text-sm text-gray-900"
                />
              </div>

              <button
                onClick={handleSaveWa}
                className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-3 rounded-xl flex items-center justify-center gap-2 transition-colors"
              >
                {status === 'success' ? <CheckCircle size={20} /> : <Save size={20} />}
                {status === 'success' ? 'Salvo com Sucesso!' : 'Salvar Configurações'}
              </button>
            </div>
            
            <div className="bg-gray-100 p-8 rounded-2xl text-gray-500 text-sm">
                <p>Estas configurações permitem que o sistema envie mensagens reais usando a Cloud API da Meta. Para receber mensagens, é necessária uma implementação de Backend com Webhooks.</p>
            </div>
          </div>
        )}

        {/* --- GENERAL TAB --- */}
        {activeTab === 'general' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 animate-in fade-in slide-in-from-bottom-4 duration-300">
                {/* Tag Manager */}
                <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm space-y-6">
                     <div className="flex justify-between items-center border-b border-gray-100 pb-4">
                         <h2 className="text-lg font-bold text-gray-800 flex items-center gap-2">
                            <Tag className="text-blue-600" /> Gerenciar Tags do CRM
                         </h2>
                     </div>

                     <div className="flex gap-2">
                        <input 
                            type="text" 
                            value={newTag}
                            onChange={(e) => setNewTag(e.target.value)}
                            placeholder="Nova tag (ex: Boleto Pendente)"
                            className="flex-1 p-3 bg-white border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none text-gray-900"
                        />
                        <button 
                            onClick={handleAddTag}
                            className="bg-blue-600 hover:bg-blue-700 text-white p-3 rounded-xl transition-colors"
                        >
                            <Plus size={20} />
                        </button>
                     </div>

                     <div className="flex flex-wrap gap-2">
                        {crmTags.map((tag, idx) => (
                            <div key={idx} className="bg-blue-50 text-blue-800 px-3 py-1.5 rounded-lg text-sm font-medium flex items-center gap-2 border border-blue-100">
                                {tag}
                                <button 
                                    onClick={() => handleRemoveTag(tag)}
                                    className="text-blue-400 hover:text-red-500 transition-colors"
                                >
                                    <Trash2 size={14} />
                                </button>
                            </div>
                        ))}
                     </div>
                </div>

                <div className="space-y-8">
                     {/* Backup & Restore */}
                    <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm space-y-6">
                        <div className="flex justify-between items-center border-b border-gray-100 pb-4">
                            <h2 className="text-lg font-bold text-gray-800 flex items-center gap-2">
                                <Database className="text-orange-600" /> Backup e Dados
                            </h2>
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4">
                            <button 
                                onClick={handleExportData}
                                className="flex flex-col items-center justify-center gap-2 p-6 rounded-xl border-2 border-dashed border-gray-300 hover:border-blue-500 hover:bg-blue-50 transition-all text-gray-600 hover:text-blue-700"
                            >
                                <Download size={32} />
                                <span className="font-semibold text-sm">Exportar Backup</span>
                                <span className="text-xs text-gray-400">Salvar JSON</span>
                            </button>

                            <label className="flex flex-col items-center justify-center gap-2 p-6 rounded-xl border-2 border-dashed border-gray-300 hover:border-green-500 hover:bg-green-50 transition-all text-gray-600 hover:text-green-700 cursor-pointer">
                                <Upload size={32} />
                                <span className="font-semibold text-sm">Importar Dados</span>
                                <span className="text-xs text-gray-400">Carregar JSON</span>
                                <input type="file" onChange={handleImportData} className="hidden" accept=".json" />
                            </label>
                        </div>
                        {status === 'success' && <p className="text-green-600 text-sm text-center font-medium">Operação realizada com sucesso!</p>}
                    </div>

                    {/* Preferences */}
                    <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm space-y-6">
                        <h2 className="text-lg font-bold text-gray-800 flex items-center gap-2">
                            <SettingsIcon className="text-gray-600" /> Preferências
                        </h2>
                        
                        <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                                <div className="p-2 bg-yellow-100 text-yellow-600 rounded-lg">
                                    <Bell size={20} />
                                </div>
                                <div>
                                    <p className="font-medium text-gray-900">Notificações</p>
                                    <p className="text-xs text-gray-500">Receber alertas de novas mensagens</p>
                                </div>
                            </div>
                            <button 
                                onClick={() => setNotificationsEnabled(!notificationsEnabled)}
                                className={clsx("w-12 h-6 rounded-full relative transition-colors", notificationsEnabled ? "bg-green-500" : "bg-gray-300")}
                            >
                                <div className={clsx("w-4 h-4 bg-white rounded-full absolute top-1 transition-all", notificationsEnabled ? "left-7" : "left-1")} />
                            </button>
                        </div>

                         <div className="flex items-center justify-between opacity-50 pointer-events-none" title="Em breve">
                            <div className="flex items-center gap-3">
                                <div className="p-2 bg-gray-100 text-gray-600 rounded-lg">
                                    <Moon size={20} />
                                </div>
                                <div>
                                    <p className="font-medium text-gray-900">Modo Escuro</p>
                                    <p className="text-xs text-gray-500">Tema dark para a interface</p>
                                </div>
                            </div>
                            <button className="w-12 h-6 rounded-full relative bg-gray-300">
                                <div className="w-4 h-4 bg-white rounded-full absolute top-1 left-1" />
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        )}

      </div>
    </div>
  );
};