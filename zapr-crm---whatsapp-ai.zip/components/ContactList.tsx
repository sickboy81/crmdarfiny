import React, { useState, useMemo } from 'react';
import { Contact } from '../types';
import { Search, Filter, MoreHorizontal, UserPlus, Tag, X, Check } from 'lucide-react';
import clsx from 'clsx';

interface ContactListProps {
    contacts: Contact[];
}

export const ContactList: React.FC<ContactListProps> = ({ contacts }) => {
    const [filterText, setFilterText] = useState('');
    const [selectedTags, setSelectedTags] = useState<string[]>([]);
    const [showFilters, setShowFilters] = useState(false);

    // Extrai todas as tags únicas dos contatos
    const allTags = useMemo(() => {
        const tags = new Set<string>();
        contacts.forEach(contact => {
            contact.tags.forEach(tag => tags.add(tag));
        });
        return Array.from(tags);
    }, [contacts]);

    // Lógica de filtragem combinada (Texto E Tags)
    const filteredContacts = contacts.filter(contact => {
        const matchesText = 
            contact.name.toLowerCase().includes(filterText.toLowerCase()) || 
            contact.company?.toLowerCase().includes(filterText.toLowerCase());
        
        const matchesTags = selectedTags.length === 0 || 
            selectedTags.some(tag => contact.tags.includes(tag));

        return matchesText && matchesTags;
    });

    const toggleTag = (tag: string) => {
        setSelectedTags(prev => 
            prev.includes(tag) 
                ? prev.filter(t => t !== tag) 
                : [...prev, tag]
        );
    };

    const clearFilters = () => {
        setSelectedTags([]);
        setFilterText('');
    };

  return (
    <div className="p-8 h-full overflow-y-auto bg-gray-50/50">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
            <h1 className="text-2xl font-bold text-gray-900">Contatos</h1>
            <p className="text-gray-500">Gerencie seus leads e clientes.</p>
        </div>
        <button className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors shadow-sm">
            <UserPlus size={18} />
            Novo Contato
        </button>
      </header>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        {/* Toolbar */}
        <div className="p-4 border-b border-gray-100 bg-white space-y-4">
            <div className="flex flex-col sm:flex-row gap-4 justify-between">
                <div className="relative max-w-md w-full">
                    <Search size={18} className="absolute left-3 top-3 text-gray-400" />
                    <input 
                        type="text" 
                        placeholder="Buscar por nome, empresa..." 
                        value={filterText}
                        onChange={(e) => setFilterText(e.target.value)}
                        className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                    />
                </div>
                <button 
                    onClick={() => setShowFilters(!showFilters)}
                    className={clsx(
                        "flex items-center gap-2 px-4 py-2 border rounded-lg transition-colors",
                        showFilters || selectedTags.length > 0 
                            ? "bg-blue-50 border-blue-200 text-blue-700" 
                            : "border-gray-200 hover:bg-gray-50 text-gray-600"
                    )}
                >
                    <Filter size={18} />
                    <span>Filtros</span>
                    {selectedTags.length > 0 && (
                        <span className="bg-blue-600 text-white text-[10px] px-1.5 py-0.5 rounded-full ml-1 font-bold">
                            {selectedTags.length}
                        </span>
                    )}
                </button>
            </div>

            {/* Filter Area (Collapsible) */}
            {(showFilters || selectedTags.length > 0) && (
                <div className="pt-2 animate-in slide-in-from-top-2 fade-in duration-200">
                    <div className="flex items-center justify-between mb-2">
                        <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider flex items-center gap-1">
                            <Tag size={12} /> Filtrar por Tags
                        </span>
                        {selectedTags.length > 0 && (
                            <button 
                                onClick={() => setSelectedTags([])}
                                className="text-xs text-red-500 hover:text-red-700 flex items-center gap-1"
                            >
                                <X size={12} /> Limpar tags
                            </button>
                        )}
                    </div>
                    <div className="flex flex-wrap gap-2">
                        {allTags.map(tag => {
                            const isSelected = selectedTags.includes(tag);
                            return (
                                <button
                                    key={tag}
                                    onClick={() => toggleTag(tag)}
                                    className={clsx(
                                        "px-3 py-1.5 rounded-full text-sm border transition-all flex items-center gap-2",
                                        isSelected 
                                            ? "bg-blue-100 border-blue-200 text-blue-800 font-medium" 
                                            : "bg-white border-gray-200 text-gray-600 hover:border-gray-300 hover:bg-gray-50"
                                    )}
                                >
                                    {tag}
                                    {isSelected && <Check size={14} />}
                                </button>
                            );
                        })}
                    </div>
                </div>
            )}
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
                <thead>
                    <tr className="bg-gray-50/50 text-gray-500 text-xs uppercase font-medium border-b border-gray-100">
                        <th className="p-4 pl-6">Nome</th>
                        <th className="p-4">Empresa</th>
                        <th className="p-4">Status</th>
                        <th className="p-4">Tags</th>
                        <th className="p-4">Última Atividade</th>
                        <th className="p-4"></th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                    {filteredContacts.map(contact => (
                        <tr key={contact.id} className="hover:bg-gray-50 transition-colors group">
                            <td className="p-4 pl-6">
                                <div className="flex items-center gap-3">
                                    <img src={contact.avatar} alt="" className="w-10 h-10 rounded-full object-cover" />
                                    <div>
                                        <div className="font-semibold text-gray-900">{contact.name}</div>
                                        <div className="text-xs text-gray-400">{contact.phoneNumber}</div>
                                    </div>
                                </div>
                            </td>
                            <td className="p-4 text-sm text-gray-600 font-medium">
                                {contact.company || '-'}
                            </td>
                            <td className="p-4">
                                <span className={clsx(
                                    "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium capitalize",
                                    contact.status === 'active' ? 'bg-green-100 text-green-800' : 
                                    contact.status === 'archived' ? 'bg-gray-100 text-gray-800' : 'bg-red-100 text-red-800'
                                )}>
                                    {contact.status === 'active' ? 'Ativo' : contact.status === 'archived' ? 'Arquivado' : 'Bloqueado'}
                                </span>
                            </td>
                            <td className="p-4">
                                <div className="flex gap-1 flex-wrap">
                                    {contact.tags.map(tag => (
                                        <span key={tag} className={clsx(
                                            "px-2 py-1 rounded text-xs border transition-colors",
                                            selectedTags.includes(tag) 
                                                ? "bg-blue-100 text-blue-700 border-blue-200 font-medium" 
                                                : "bg-gray-50 text-gray-600 border-gray-200"
                                        )}>
                                            {tag}
                                        </span>
                                    ))}
                                </div>
                            </td>
                            <td className="p-4 text-sm text-gray-500">
                                {contact.lastSeen}
                            </td>
                            <td className="p-4 text-right">
                                <button className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded opacity-0 group-hover:opacity-100 transition-all">
                                    <MoreHorizontal size={18} />
                                </button>
                            </td>
                        </tr>
                    ))}
                    {filteredContacts.length === 0 && (
                        <tr>
                            <td colSpan={6} className="p-12 text-center text-gray-500">
                                <div className="flex flex-col items-center justify-center gap-2">
                                    <Search size={32} className="text-gray-300" />
                                    <p>Nenhum contato encontrado com os filtros atuais.</p>
                                    {(filterText || selectedTags.length > 0) && (
                                        <button 
                                            onClick={clearFilters}
                                            className="text-sm text-blue-600 hover:underline mt-2"
                                        >
                                            Limpar filtros
                                        </button>
                                    )}
                                </div>
                            </td>
                        </tr>
                    )}
                </tbody>
            </table>
        </div>
      </div>
    </div>
  );
};