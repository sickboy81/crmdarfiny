import React, { useState, useEffect, useRef } from 'react';
import { Chat, Message, Contact, AIAnalysis } from '../types';
import { MOCK_CHATS, MOCK_MESSAGES, PIPELINE_STAGES } from '../constants';
import { Send, Phone, Video, MoreVertical, Paperclip, Smile, Search, Sparkles, BrainCircuit, Bot, MessageSquare, Wand2, X, MousePointerClick, UserCog, Power, AlertCircle, Plus, Calendar, Tag, CheckCircle2, FileUp, FileText, Image as ImageIcon, PanelRight, Briefcase, DollarSign, StickyNote, Trash2 } from 'lucide-react';
import clsx from 'clsx';
import { generateSmartReply, analyzeConversation, generateTemplate, generateCustomerSimulation, generateBotAutoResponse } from '../services/geminiService';
import { getWhatsAppConfig, sendRealWhatsAppMessage } from '../services/whatsappService';

interface ChatInterfaceProps {
    contacts: Contact[];
    onUpdateContact: (id: string, updates: Partial<Contact>) => void;
}

export const ChatInterface: React.FC<ChatInterfaceProps> = ({ contacts, onUpdateContact }) => {
  const [selectedChatId, setSelectedChatId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Record<string, Message[]>>(MOCK_MESSAGES);
  const [chats, setChats] = useState<Chat[]>(MOCK_CHATS);
  const [input, setInput] = useState('');
  const [isAIThinking, setIsAIThinking] = useState(false);
  const [aiAnalysis, setAiAnalysis] = useState<AIAnalysis | null>(null);
  const [sendingError, setSendingError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [isSending, setIsSending] = useState(false);
  
  // File Upload State
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  // Bot & Simulation State
  const [isBotActive, setIsBotActive] = useState(false);
  const [isSimulatingCustomer, setIsSimulatingCustomer] = useState(false);

  // Template Generator State
  const [isTemplateModalOpen, setIsTemplateModalOpen] = useState(false);
  const [templateTopic, setTemplateTopic] = useState('');
  const [templateTone, setTemplateTone] = useState('Profissional');
  const [includeButtons, setIncludeButtons] = useState(false);
  const [generatedTemplate, setGeneratedTemplate] = useState('');
  const [isGeneratingTemplate, setIsGeneratingTemplate] = useState(false);

  // Actions Menu State
  const [isActionsMenuOpen, setIsActionsMenuOpen] = useState(false);

  // CRM Sidebar State
  const [isContactInfoOpen, setIsContactInfoOpen] = useState(false);
  const [newTagInput, setNewTagInput] = useState('');

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const selectedChat = chats.find(c => c.id === selectedChatId);
  const currentMessages = selectedChatId ? messages[selectedChatId] || [] : [];
  // Use contacts from props instead of MOCK_CONTACTS
  const contact = selectedChat ? contacts.find(c => c.id === selectedChat.contactId) : null;

  useEffect(() => {
    scrollToBottom();
  }, [currentMessages, selectedChatId]);

  // Reset analysis and menus when chat changes
  useEffect(() => {
    setAiAnalysis(null);
    setIsBotActive(false); 
    setSendingError(null);
    setSuccessMessage(null);
    setIsActionsMenuOpen(false);
    clearFile();
    // Default sidebar to open on desktop
    if (window.innerWidth >= 1024) setIsContactInfoOpen(true);
  }, [selectedChatId]);

  // Bot Logic: Watch for customer messages
  useEffect(() => {
    if (!isBotActive || !selectedChatId || !contact) return;

    const lastMsg = currentMessages[currentMessages.length - 1];
    if (lastMsg && lastMsg.senderId !== 'me' && lastMsg.type !== 'system') {
        const runBot = async () => {
            setIsAIThinking(true);
            await new Promise(r => setTimeout(r, 1000));
            const botReply = await generateBotAutoResponse(currentMessages, contact.name, messages);
            const newMessage: Message = {
                id: Date.now().toString(),
                chatId: selectedChatId,
                senderId: 'me',
                content: botReply,
                timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                status: 'read', 
                type: 'text'
            };
            addMessage(selectedChatId, newMessage);
            setIsAIThinking(false);
        };
        runBot();
    }
  }, [messages, isBotActive, selectedChatId]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const addMessage = (chatId: string, message: Message) => {
    setMessages(prev => ({
        ...prev,
        [chatId]: [...(prev[chatId] || []), message]
    }));
    setChats(prev => prev.map(c => 
        c.id === chatId ? { ...c, lastMessage: message, unreadCount: message.senderId === 'me' ? 0 : c.unreadCount + 1 } : c
    ));
  };

  const showSuccess = (msg: string) => {
      setSuccessMessage(msg);
      setTimeout(() => setSuccessMessage(null), 3000);
  };

  const handleSendMessage = async () => {
    if ((!input.trim() && !selectedFile) || !selectedChatId || !contact) return;
    setSendingError(null);
    setIsSending(true);

    const whatsappConfig = getWhatsAppConfig();
    let status: 'sent' | 'failed' = 'sent';

    if (whatsappConfig?.accessToken && whatsappConfig?.phoneNumberId && !selectedFile) {
        const result = await sendRealWhatsAppMessage(contact.phoneNumber, input);
        if (!result.success) {
            status = 'failed';
            setSendingError(`Falha no envio Real: ${result.error}`);
        }
    } else {
        await new Promise(r => setTimeout(r, 300));
    }

    let messageType: 'text' | 'image' = 'text';
    let content = input;

    if (selectedFile) {
        if (selectedFile.type.startsWith('image/')) {
            messageType = 'image';
            content = previewUrl || '';
        } else {
            messageType = 'text';
            content = `📄 Arquivo enviado: ${selectedFile.name}\n${input}`;
        }
    }

    const newMessage: Message = {
      id: Date.now().toString(),
      chatId: selectedChatId,
      senderId: 'me',
      content: content,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      status: status === 'failed' ? 'failed' : 'sent',
      type: messageType
    };

    if (status !== 'failed') {
        setInput('');
        clearFile();
    }
    
    addMessage(selectedChatId, newMessage);
    setIsSending(false);
  };

  const handleSimulateCustomer = async () => {
    if (!selectedChatId || !contact) return;
    
    setIsSimulatingCustomer(true);
    setIsAIThinking(true);

    const profile = contact.tags.join(', ') + (contact.company ? ` trabalha na ${contact.company}` : '');
    const reply = await generateCustomerSimulation(currentMessages, contact.name, profile);
    
    setIsAIThinking(false);
    setIsSimulatingCustomer(false);

    const newMessage: Message = {
        id: Date.now().toString(),
        chatId: selectedChatId,
        senderId: contact.id, 
        content: reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        status: 'delivered',
        type: 'text'
    };
    
    addMessage(selectedChatId, newMessage);
  };

  const handleSmartReply = async () => {
    if (!selectedChatId || !contact) return;
    setSendingError(null);
    setIsAIThinking(true);
    try {
      const suggestion = await generateSmartReply(currentMessages, contact.name);
      if (suggestion.startsWith("Erro") || suggestion.includes("Não foi possível")) {
        setSendingError(suggestion);
      } else if (suggestion) {
        setInput(suggestion);
      }
    } catch (error) {
      console.error("Smart Reply Error:", error);
      setSendingError("Ocorreu um erro ao gerar a sugestão. Tente novamente.");
    } finally {
      setIsAIThinking(false);
    }
  };

  const handleAnalyzeChat = async () => {
    if (!selectedChatId || !contact) return;
    setSendingError(null);
    setIsAIThinking(true);
    try {
      const analysis = await analyzeConversation(currentMessages, contact.name);
      if (analysis) {
        setAiAnalysis(analysis as AIAnalysis);
        setIsContactInfoOpen(true); // Open sidebar to show context if analysis is done
      } else {
        setSendingError("Não foi possível analisar a conversa. Verifique sua chave de API.");
      }
    } catch (error) {
      console.error("Analysis Error:", error);
      setSendingError("Erro inesperado ao conectar com a IA.");
    } finally {
      setIsAIThinking(false);
    }
  };

  const handleQuickAction = (action: 'lead' | 'schedule' | 'analyze') => {
      setIsActionsMenuOpen(false);
      if (!contact) return;

      if (action === 'lead') {
          onUpdateContact(contact.id, { tags: [...contact.tags, 'Lead Qualificado'] });
          showSuccess(`${contact.name} foi marcado como Lead Qualificado!`);
      } else if (action === 'schedule') {
          showSuccess(`Lembrete de retorno agendado para amanhã às 09:00.`);
      } else if (action === 'analyze') {
          handleAnalyzeChat();
      }
  };

  const handleGenerateTemplate = async () => {
    if (!templateTopic.trim()) return;
    setIsGeneratingTemplate(true);
    const result = await generateTemplate(templateTopic, templateTone, includeButtons);
    setIsGeneratingTemplate(false);
    setGeneratedTemplate(result);
  };

  const applyTemplate = () => {
    if (!contact) return;
    const finalizedText = generatedTemplate.replace('{{Nome}}', contact.name.split(' ')[0]);
    setInput(finalizedText);
    setIsTemplateModalOpen(false);
    setGeneratedTemplate('');
    setTemplateTopic('');
    setIncludeButtons(false);
  };

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
      const file = event.target.files?.[0];
      if (file) {
          setSelectedFile(file);
          if (file.type.startsWith('image/')) {
              const url = URL.createObjectURL(file);
              setPreviewUrl(url);
          } else {
              setPreviewUrl(null);
          }
      }
      event.target.value = '';
  };

  const clearFile = () => {
      if (previewUrl) URL.revokeObjectURL(previewUrl);
      setSelectedFile(null);
      setPreviewUrl(null);
  };

  const renderTemplatePreview = () => {
      if (!generatedTemplate) return null;
      const buttonRegex = /\[Botão: (.*?)\]/g;
      const buttons: string[] = [];
      let match;
      while ((match = buttonRegex.exec(generatedTemplate)) !== null) {
          buttons.push(match[1]);
      }
      const cleanText = generatedTemplate.replace(buttonRegex, '').trim();

      return (
        <div className="bg-gray-50 p-4 rounded-xl border border-gray-200 relative group">
            <p className="text-gray-800 whitespace-pre-wrap text-sm">{cleanText}</p>
            {buttons.length > 0 && (
                <div className="mt-4 pt-3 border-t border-gray-200">
                    <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider mb-2">Botões Interativos (Quick Reply)</p>
                    <div className="flex flex-wrap gap-2">
                        {buttons.map((btn, idx) => (
                            <div key={idx} className="bg-white border border-gray-200 text-blue-600 px-4 py-2 rounded-lg text-sm font-semibold shadow-sm text-center min-w-[100px] cursor-default">
                                {btn}
                            </div>
                        ))}
                    </div>
                </div>
            )}
             <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                <button 
                onClick={() => navigator.clipboard.writeText(generatedTemplate)}
                className="text-xs bg-white border px-2 py-1 rounded shadow-sm text-gray-500 hover:text-gray-800"
                >
                Copiar
                </button>
            </div>
        </div>
      );
  };

  return (
    <div className="flex h-full bg-white relative">
      <input type="file" ref={fileInputRef} onChange={handleFileSelect} className="hidden" />

      {/* Template Generator Modal */}
      {isTemplateModalOpen && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="p-4 border-b border-gray-100 flex justify-between items-center bg-gradient-to-r from-purple-50 to-white">
              <div className="flex items-center gap-2 text-purple-700">
                <Wand2 size={20} />
                <h3 className="font-bold">Gerador de Template AI</h3>
              </div>
              <button onClick={() => setIsTemplateModalOpen(false)} className="text-gray-400 hover:text-gray-600"><X size={20} /></button>
            </div>
            
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Qual o objetivo da mensagem?</label>
                <input 
                  type="text" 
                  value={templateTopic}
                  onChange={(e) => setTemplateTopic(e.target.value)}
                  placeholder="Ex: Cobrança de fatura, Promoção Black Friday..."
                  className="w-full p-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 focus:outline-none"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Tom de voz</label>
                <div className="flex gap-2 mb-4">
                  {['Profissional', 'Amigável', 'Urgente', 'Entusiasmado'].map(tone => (
                    <button
                      key={tone}
                      onClick={() => setTemplateTone(tone)}
                      className={clsx(
                        "px-3 py-1.5 rounded-lg text-sm border transition-all",
                        templateTone === tone ? "bg-purple-100 border-purple-200 text-purple-700 font-medium" : "bg-white border-gray-200 text-gray-600 hover:bg-gray-50"
                      )}
                    >
                      {tone}
                    </button>
                  ))}
                </div>

                <div 
                    onClick={() => setIncludeButtons(!includeButtons)}
                    className={clsx(
                        "flex items-center gap-3 p-3 rounded-xl border cursor-pointer transition-colors",
                        includeButtons ? "border-purple-200 bg-purple-50" : "border-gray-200 hover:bg-gray-50"
                    )}
                >
                    <div className={clsx(
                        "w-5 h-5 rounded border flex items-center justify-center transition-colors",
                        includeButtons ? "bg-purple-600 border-purple-600" : "bg-white border-gray-300"
                    )}>
                        {includeButtons && <div className="w-2 h-2 bg-white rounded-full" />}
                    </div>
                    <div className="flex items-center gap-2 text-gray-700 text-sm font-medium">
                        <MousePointerClick size={16} />
                        <span>Incluir botões interativos (Quick Reply)</span>
                    </div>
                </div>
              </div>

              {renderTemplatePreview()}

              <button
                onClick={handleGenerateTemplate}
                disabled={isGeneratingTemplate || !templateTopic}
                className="w-full bg-purple-600 hover:bg-purple-700 text-white font-medium py-3 rounded-xl flex items-center justify-center gap-2 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isGeneratingTemplate ? (<><Sparkles size={18} className="animate-spin" /> Gerando...</>) : (<><Wand2 size={18} /> Gerar Template</>)}
              </button>
              
              {generatedTemplate && (
                <button
                  onClick={applyTemplate}
                  className="w-full bg-green-600 hover:bg-green-700 text-white font-medium py-3 rounded-xl flex items-center justify-center gap-2 transition-colors"
                >
                  Usar este Template
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Sidebar List */}
      <div className={clsx("w-full md:w-80 lg:w-96 border-r border-gray-200 flex flex-col h-full", selectedChatId ? "hidden md:flex" : "flex")}>
        <div className="p-4 bg-gray-50 border-b border-gray-200">
          <div className="flex justify-between items-center mb-4">
             <h2 className="text-xl font-bold text-gray-800">Mensagens</h2>
             <div className="flex gap-2">
               <button className="p-2 hover:bg-gray-200 rounded-full text-gray-500"><MoreVertical size={20} /></button>
             </div>
          </div>
          <div className="relative">
            <input 
              type="text" 
              placeholder="Buscar conversas..." 
              className="w-full pl-10 pr-4 py-2 bg-white border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
            />
            <Search size={16} className="absolute left-3 top-3 text-gray-400" />
          </div>
        </div>
        
        <div className="flex-1 overflow-y-auto">
          {chats.map(chat => {
            const chatContact = contacts.find(c => c.id === chat.contactId);
            if (!chatContact) return null;
            return (
              <div 
                key={chat.id}
                onClick={() => setSelectedChatId(chat.id)}
                className={clsx(
                  "flex items-center gap-3 p-4 border-b border-gray-100 cursor-pointer hover:bg-gray-50 transition-colors",
                  selectedChatId === chat.id ? "bg-green-50 hover:bg-green-50 border-l-4 border-l-green-500" : "border-l-4 border-l-transparent"
                )}
              >
                <img src={chatContact.avatar} alt={chatContact.name} className="w-12 h-12 rounded-full object-cover" />
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-baseline mb-1">
                    <h3 className="font-semibold text-gray-900 truncate">{chatContact.name}</h3>
                    <span className="text-xs text-gray-400">{chat.lastMessage.timestamp}</span>
                  </div>
                  <p className="text-sm text-gray-500 truncate">{chat.lastMessage.senderId === 'me' ? 'Você: ' : ''}{chat.lastMessage.content}</p>
                </div>
                {chat.unreadCount > 0 && (
                  <div className="bg-green-500 text-white text-xs font-bold w-5 h-5 rounded-full flex items-center justify-center">
                    {chat.unreadCount}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Main Chat Area */}
      {selectedChatId && contact ? (
        <div className="flex-1 flex overflow-hidden">
            {/* Chat Column */}
            <div className="flex-1 flex flex-col h-full bg-[#efeae2] relative min-w-0">
                <div className="absolute inset-0 bg-[url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png')] opacity-10 pointer-events-none"></div>

                {/* Chat Header */}
                <div className="bg-gray-50 p-3 px-6 border-b border-gray-200 flex flex-col md:flex-row justify-between items-center z-10 shadow-sm gap-4 md:gap-0 shrink-0">
                    <div className="flex items-center gap-4 w-full md:w-auto">
                        <button onClick={() => setSelectedChatId(null)} className="md:hidden text-gray-500 mr-2">Back</button>
                        <img src={contact.avatar} alt={contact.name} className="w-10 h-10 rounded-full object-cover" />
                        <div>
                            <h3 className="font-bold text-gray-800">{contact.name}</h3>
                            <div className="flex items-center gap-2">
                                <p className="text-xs text-green-600 font-medium">Online</p>
                                {isBotActive && <span className="text-xs bg-purple-100 text-purple-700 px-2 py-0.5 rounded-full font-bold">Bot Ativo</span>}
                            </div>
                        </div>
                    </div>
                    <div className="flex items-center gap-2 text-gray-500 overflow-x-auto w-full md:w-auto pb-2 md:pb-0">
                        <button 
                            onClick={() => setIsBotActive(!isBotActive)}
                            className={clsx(
                                "flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all whitespace-nowrap",
                                isBotActive ? "bg-purple-600 text-white shadow-md" : "bg-gray-200 text-gray-600 hover:bg-gray-300"
                            )}
                            title={isBotActive ? "Desativar Bot Automático" : "Ativar Bot Automático"}
                        >
                            <Power size={14} />
                            {isBotActive ? "Bot ON" : "Bot OFF"}
                        </button>

                        <button 
                            onClick={handleSimulateCustomer} 
                            disabled={isSimulatingCustomer}
                            className="flex items-center gap-2 px-3 py-1.5 bg-blue-50 text-blue-700 hover:bg-blue-100 rounded-lg text-xs font-semibold whitespace-nowrap" 
                            title="Simular resposta do cliente com IA"
                        >
                            {isSimulatingCustomer ? <Sparkles size={14} className="animate-spin" /> : <UserCog size={14} />}
                            Simular Cliente
                        </button>

                        <div className="w-px h-6 bg-gray-300 mx-2 hidden md:block"></div>
                        
                        <button onClick={handleAnalyzeChat} className="p-2 hover:bg-gray-200 rounded-full text-purple-600" title="Analisar com IA">
                            <BrainCircuit size={20} />
                        </button>
                        <button 
                            onClick={() => setIsContactInfoOpen(!isContactInfoOpen)}
                            className={clsx("p-2 rounded-full transition-colors", isContactInfoOpen ? "bg-green-100 text-green-600" : "hover:bg-gray-200")}
                            title="Informações do Contato"
                        >
                            <PanelRight size={20} />
                        </button>
                    </div>
                </div>

                {/* Messages & Input Container */}
                <div className="flex-1 flex flex-col min-h-0">
                    {/* AI Analysis Panel */}
                    {aiAnalysis && (
                        <div className="bg-purple-50 border-b border-purple-100 p-4 z-10 flex flex-col md:flex-row gap-4 items-start md:items-center text-sm animate-in slide-in-from-top-4 fade-in shrink-0">
                            <div className="flex items-center gap-2">
                                <Bot className="text-purple-600" size={20} />
                                <span className="font-bold text-purple-800">Insight Gemini:</span>
                            </div>
                            <div className="flex-1 grid grid-cols-1 md:grid-cols-3 gap-4 w-full">
                                <div className="bg-white/60 p-2 rounded border border-purple-100">
                                    <span className="text-xs text-purple-500 uppercase font-bold">Sentimento</span>
                                    <div className="font-medium text-purple-900 capitalize">{aiAnalysis.sentiment}</div>
                                </div>
                                <div className="bg-white/60 p-2 rounded border border-purple-100">
                                    <span className="text-xs text-purple-500 uppercase font-bold">Intenção</span>
                                    <div className="font-medium text-purple-900 capitalize">{aiAnalysis.intent}</div>
                                </div>
                                <div className="bg-white/60 p-2 rounded border border-purple-100">
                                    <span className="text-xs text-purple-500 uppercase font-bold">Resumo</span>
                                    <div className="font-medium text-purple-900 truncate">{aiAnalysis.summary}</div>
                                </div>
                            </div>
                            <button onClick={() => setAiAnalysis(null)} className="text-purple-400 hover:text-purple-700 text-xs">Fechar</button>
                        </div>
                    )}

                    {/* Messages Area */}
                    <div className="flex-1 overflow-y-auto p-4 md:p-8 space-y-4 z-0">
                        {currentMessages.map((msg) => (
                            <div key={msg.id} className={clsx("flex", msg.senderId === 'me' ? "justify-end" : "justify-start")}>
                                <div className={clsx(
                                    "max-w-[85%] md:max-w-[65%] rounded-lg p-3 shadow-sm relative",
                                    msg.senderId === 'me' ? "bg-green-100 text-gray-800 rounded-tr-none" : "bg-white text-gray-800 rounded-tl-none"
                                )}>
                                    {msg.type === 'image' ? (
                                        <div className="mb-1">
                                            <img src={msg.content} alt="Imagem enviada" className="rounded-lg max-h-64 object-cover w-full" />
                                        </div>
                                    ) : (
                                        <p className="text-sm leading-relaxed whitespace-pre-wrap">{msg.content}</p>
                                    )}
                                    
                                    <span className="text-[10px] text-gray-500 block text-right mt-1">
                                        {msg.timestamp}
                                        {msg.senderId === 'me' && (
                                            <span className="ml-1 text-blue-400">✓✓</span>
                                        )}
                                        {msg.status === 'failed' && (
                                            <span className="ml-1 text-red-500 font-bold">!</span>
                                        )}
                                    </span>
                                </div>
                            </div>
                        ))}
                        <div ref={messagesEndRef} />
                    </div>

                    {/* Input Area */}
                    <div className="bg-gray-50 p-4 border-t border-gray-200 z-10 relative shrink-0">
                        {selectedFile && (
                            <div className="absolute bottom-full left-0 w-full bg-white/95 border-t border-gray-200 p-3 px-6 backdrop-blur-sm z-20 animate-in slide-in-from-bottom-2">
                                <div className="flex items-center justify-between">
                                    <div className="flex items-center gap-3">
                                        {previewUrl ? (
                                            <div className="relative w-12 h-12 rounded-lg overflow-hidden border border-gray-200">
                                                <img src={previewUrl} alt="Preview" className="w-full h-full object-cover" />
                                            </div>
                                        ) : (
                                            <div className="w-12 h-12 rounded-lg bg-gray-100 flex items-center justify-center text-gray-500"><FileText size={24} /></div>
                                        )}
                                        <div>
                                            <p className="text-sm font-semibold text-gray-700 truncate max-w-[200px]">{selectedFile.name}</p>
                                            <p className="text-xs text-gray-400">{(selectedFile.size / 1024).toFixed(1)} KB</p>
                                        </div>
                                    </div>
                                    <button onClick={clearFile} className="p-1.5 bg-gray-100 hover:bg-gray-200 rounded-full text-gray-500 transition-colors"><X size={16} /></button>
                                </div>
                            </div>
                        )}

                        {sendingError && (
                            <div className="bg-red-50 text-red-600 text-xs p-2 rounded mb-2 flex items-center gap-2"><AlertCircle size={14} />{sendingError}</div>
                        )}

                        {successMessage && (
                            <div className="bg-green-50 text-green-700 text-xs p-2 rounded mb-2 flex items-center gap-2 animate-in fade-in slide-in-from-bottom-2"><CheckCircle2 size={14} />{successMessage}</div>
                        )}

                        {isBotActive && (
                            <div className="absolute top-0 left-0 w-full h-full bg-white/50 backdrop-blur-[1px] z-20 flex items-center justify-center">
                                <div className="bg-white px-4 py-2 rounded-full shadow-lg border border-purple-100 flex items-center gap-2 text-sm text-purple-700">
                                    <Bot size={16} /><span className="font-medium">Bot Automático Ativo</span><button onClick={() => setIsBotActive(false)} className="text-xs underline ml-2">Desativar</button>
                                </div>
                            </div>
                        )}

                        {isAIThinking && (
                            <div className="text-xs text-purple-600 mb-2 flex items-center gap-2 animate-pulse font-medium px-2"><Sparkles size={14} />Gemini está digitando...</div>
                        )}
                        <div className="flex items-center gap-3 relative">
                            <div className="relative">
                                <button onClick={() => setIsActionsMenuOpen(!isActionsMenuOpen)} className={clsx("p-2 rounded-full transition-colors", isActionsMenuOpen ? "bg-purple-100 text-purple-600 rotate-45" : "bg-gray-200 text-gray-500 hover:bg-gray-300")} title="Ações Rápidas"><Plus size={24} className="transition-transform duration-200" /></button>
                                {isActionsMenuOpen && (
                                    <div className="absolute bottom-14 left-0 w-56 bg-white rounded-xl shadow-xl border border-gray-100 p-1 z-30 animate-in slide-in-from-bottom-2 fade-in">
                                        <button onClick={() => handleQuickAction('lead')} className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-gray-50 text-left text-sm text-gray-700 transition-colors"><div className="bg-orange-100 text-orange-600 p-1.5 rounded-md"><Tag size={16} /></div><span>Marcar como Lead</span></button>
                                        <button onClick={() => handleQuickAction('schedule')} className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-gray-50 text-left text-sm text-gray-700 transition-colors"><div className="bg-blue-100 text-blue-600 p-1.5 rounded-md"><Calendar size={16} /></div><span>Agendar Lembrete</span></button>
                                        <button onClick={() => handleQuickAction('analyze')} className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-gray-50 text-left text-sm text-gray-700 transition-colors"><div className="bg-purple-100 text-purple-600 p-1.5 rounded-md"><BrainCircuit size={16} /></div><span>Analisar com IA</span></button>
                                    </div>
                                )}
                            </div>

                            <button onClick={() => setIsTemplateModalOpen(true)} className="p-2 text-purple-600 hover:bg-purple-100 rounded-full transition-colors" title="Gerador de Template AI"><Wand2 size={24} /></button>
                            <button onClick={() => fileInputRef.current?.click()} className={clsx("p-2 rounded-full transition-colors", selectedFile ? "bg-green-100 text-green-600" : "text-gray-500 hover:bg-gray-200")} title="Enviar Arquivo"><FileUp size={24} /></button>
                            <button className="p-2 text-gray-500 hover:bg-gray-200 rounded-full"><Paperclip size={24} /></button>
                            
                            <div className="flex-1 relative">
                                <input type="text" value={input} onChange={(e) => setInput(e.target.value)} onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()} placeholder="Digite uma mensagem" disabled={isSending} className="w-full py-3 px-4 bg-white border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-green-500 pr-10" />
                                <button onClick={handleSmartReply} className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 text-purple-500 hover:bg-purple-50 rounded-full transition-colors" title="Sugerir resposta com IA"><Sparkles size={18} /></button>
                            </div>

                            <button onClick={handleSendMessage} className={clsx("p-3 rounded-xl transition-all shadow-md flex items-center justify-center", input.trim() || selectedFile ? "bg-green-600 text-white hover:bg-green-700" : "bg-gray-200 text-gray-400 cursor-not-allowed")} disabled={(!input.trim() && !selectedFile) || isSending}><Send size={20} className={isSending ? "animate-pulse" : ""} /></button>
                        </div>
                    </div>
                </div>
            </div>

            {/* CRM Sidebar */}
            {isContactInfoOpen && contact && (
                <div className="w-80 bg-white border-l border-gray-200 flex flex-col h-full shadow-2xl z-20 animate-in slide-in-from-right-10 duration-200 shrink-0">
                    <div className="p-4 border-b border-gray-100 flex items-center justify-between">
                        <h3 className="font-bold text-gray-800">Informações do Contato</h3>
                        <button onClick={() => setIsContactInfoOpen(false)} className="text-gray-400 hover:text-gray-600"><X size={20} /></button>
                    </div>

                    <div className="flex-1 overflow-y-auto p-6 space-y-6">
                        {/* Profile */}
                        <div className="flex flex-col items-center">
                            <img src={contact.avatar} className="w-20 h-20 rounded-full mb-3 object-cover shadow-md" alt="" />
                            <h2 className="text-xl font-bold text-gray-900">{contact.name}</h2>
                            <p className="text-sm text-gray-500">{contact.company || 'Empresa não informada'}</p>
                            <div className="mt-4 w-full flex justify-center gap-2">
                                <a href={`tel:${contact.phoneNumber}`} className="p-2 bg-gray-100 rounded-full text-gray-600 hover:bg-green-100 hover:text-green-600 transition-colors"><Phone size={18} /></a>
                                <button className="p-2 bg-gray-100 rounded-full text-gray-600 hover:bg-blue-100 hover:text-blue-600 transition-colors"><Video size={18} /></button>
                                <button className="p-2 bg-gray-100 rounded-full text-gray-600 hover:bg-purple-100 hover:text-purple-600 transition-colors"><Calendar size={18} /></button>
                            </div>
                        </div>

                        <hr className="border-gray-100" />

                        {/* Pipeline Section */}
                        <div className="space-y-4">
                            <h4 className="text-sm font-bold text-gray-800 flex items-center gap-2 uppercase tracking-wide">
                                <Briefcase size={16} className="text-blue-500" /> Pipeline de Vendas
                            </h4>
                            
                            <div>
                                <label className="block text-xs font-semibold text-gray-500 mb-1">Estágio do Funil</label>
                                <select 
                                    value={contact.pipelineStage || 'new'}
                                    onChange={(e) => onUpdateContact(contact.id, { pipelineStage: e.target.value as any })}
                                    className="w-full p-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm text-gray-800 focus:ring-2 focus:ring-blue-500 outline-none"
                                >
                                    {PIPELINE_STAGES.map(stage => (
                                        <option key={stage.id} value={stage.id}>{stage.label}</option>
                                    ))}
                                </select>
                            </div>

                            <div>
                                <label className="block text-xs font-semibold text-gray-500 mb-1">Valor do Negócio (R$)</label>
                                <div className="relative">
                                    <DollarSign size={16} className="absolute left-3 top-2.5 text-gray-400" />
                                    <input 
                                        type="number"
                                        value={contact.dealValue || 0}
                                        onChange={(e) => onUpdateContact(contact.id, { dealValue: Number(e.target.value) })}
                                        className="w-full pl-9 p-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm text-gray-800 focus:ring-2 focus:ring-green-500 outline-none"
                                    />
                                </div>
                            </div>
                        </div>

                        <hr className="border-gray-100" />

                        {/* Tags Section */}
                        <div className="space-y-4">
                             <h4 className="text-sm font-bold text-gray-800 flex items-center gap-2 uppercase tracking-wide">
                                <Tag size={16} className="text-orange-500" /> Tags
                            </h4>
                            <div className="flex flex-wrap gap-2">
                                {contact.tags.map(tag => (
                                    <span key={tag} className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-medium bg-orange-50 text-orange-700 border border-orange-100">
                                        {tag}
                                        <button 
                                            onClick={() => onUpdateContact(contact.id, { tags: contact.tags.filter(t => t !== tag) })}
                                            className="hover:text-red-500"
                                        >
                                            <X size={12} />
                                        </button>
                                    </span>
                                ))}
                            </div>
                            <div className="flex gap-2">
                                <input 
                                    type="text" 
                                    value={newTagInput}
                                    onChange={(e) => setNewTagInput(e.target.value)}
                                    placeholder="Add tag..."
                                    className="flex-1 p-2 bg-white border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-orange-500"
                                    onKeyPress={(e) => {
                                        if (e.key === 'Enter' && newTagInput.trim()) {
                                            if (!contact.tags.includes(newTagInput.trim())) {
                                                onUpdateContact(contact.id, { tags: [...contact.tags, newTagInput.trim()] });
                                            }
                                            setNewTagInput('');
                                        }
                                    }}
                                />
                                <button 
                                    onClick={() => {
                                        if (newTagInput.trim() && !contact.tags.includes(newTagInput.trim())) {
                                            onUpdateContact(contact.id, { tags: [...contact.tags, newTagInput.trim()] });
                                            setNewTagInput('');
                                        }
                                    }}
                                    className="p-2 bg-orange-100 text-orange-600 rounded-lg hover:bg-orange-200"
                                >
                                    <Plus size={18} />
                                </button>
                            </div>
                        </div>

                        <hr className="border-gray-100" />

                        {/* Notes Section */}
                         <div className="space-y-4">
                             <h4 className="text-sm font-bold text-gray-800 flex items-center gap-2 uppercase tracking-wide">
                                <StickyNote size={16} className="text-yellow-500" /> Notas Internas
                            </h4>
                            <textarea
                                value={contact.notes || ''}
                                onChange={(e) => onUpdateContact(contact.id, { notes: e.target.value })}
                                placeholder="Escreva observações importantes sobre este cliente..."
                                className="w-full h-32 p-3 bg-yellow-50 border border-yellow-100 rounded-lg text-sm text-gray-700 focus:ring-2 focus:ring-yellow-400 outline-none resize-none"
                            />
                        </div>
                    </div>
                </div>
            )}
        </div>
      ) : (
        <div className="flex-1 hidden md:flex flex-col items-center justify-center bg-gray-50 text-gray-400 border-b-8 border-green-500">
            <div className="w-24 h-24 bg-gray-200 rounded-full flex items-center justify-center mb-6">
                <MessageSquare size={48} className="text-gray-400 ml-1" />
            </div>
            <h2 className="text-2xl font-light text-gray-600 mb-2">Zapr Web</h2>
            <p>Selecione uma conversa para começar a atender.</p>
            <div className="mt-8 flex gap-2 text-xs font-medium text-gray-400">
                <span className="flex items-center gap-1"><Bot size={12}/> Gemini AI Enabled</span>
            </div>
        </div>
      )}
    </div>
  );
};