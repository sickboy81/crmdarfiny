
export interface Contact {
  id: string;
  name: string;
  phoneNumber: string;
  avatar: string;
  status: 'active' | 'archived' | 'blocked';
  tags: string[];
  lastSeen: string;
  email?: string;
  company?: string;
  // Novos campos para o Pipeline
  pipelineStage?: 'new' | 'qualified' | 'proposal' | 'negotiation' | 'won' | 'lost';
  dealValue?: number;
  notes?: string; // Notas internas do CRM
}

export interface Message {
  id: string;
  chatId: string;
  senderId: 'me' | string;
  content: string;
  timestamp: string;
  status: 'sent' | 'delivered' | 'read' | 'failed';
  type: 'text' | 'image' | 'system';
}

export interface Chat {
  id: string;
  contactId: string;
  unreadCount: number;
  lastMessage: Message;
  pinned: boolean;
}

export interface AIAnalysis {
  sentiment: 'positive' | 'neutral' | 'negative';
  summary: string;
  suggestedReply: string;
  intent: 'sales' | 'support' | 'inquiry' | 'spam';
}

export interface WhatsAppConfig {
  accessToken: string;
  phoneNumberId: string;
  businessAccountId?: string;
}

export interface BotConfig {
  botName: string;
  businessContext: string;
  isActive: boolean;
  useHistoryLearning: boolean;
}

export enum View {
  DASHBOARD = 'dashboard',
  INBOX = 'inbox',
  CONTACTS = 'contacts',
  CAMPAIGNS = 'campaigns',
  PIPELINE = 'pipeline',
  SETTINGS = 'settings'
}