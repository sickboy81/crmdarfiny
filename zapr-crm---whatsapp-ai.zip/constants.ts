import { Contact, Chat, Message } from './types';

export const PIPELINE_STAGES = [
    { id: 'new', label: 'Novo Lead', color: 'bg-blue-500' },
    { id: 'qualified', label: 'Qualificado', color: 'bg-purple-500' },
    { id: 'proposal', label: 'Proposta', color: 'bg-yellow-500' },
    { id: 'negotiation', label: 'Negociação', color: 'bg-orange-500' },
    { id: 'won', label: 'Fechado', color: 'bg-green-500' },
    { id: 'lost', label: 'Perdido', color: 'bg-red-500' },
] as const;

export const MOCK_CONTACTS: Contact[] = [
  {
    id: 'c1',
    name: 'Ana Silva',
    phoneNumber: '+55 11 99999-1234',
    avatar: 'https://picsum.photos/200',
    status: 'active',
    tags: ['Lead Quente', 'Interessado'],
    lastSeen: 'Hoje, 10:30',
    email: 'ana.silva@exemplo.com',
    company: 'Silva Design',
    pipelineStage: 'proposal',
    dealValue: 15000,
    notes: 'Cliente interessada no plano Enterprise. Agendar demo para próxima semana.'
  },
  {
    id: 'c2',
    name: 'Carlos Oliveira',
    phoneNumber: '+55 11 98888-5678',
    avatar: 'https://picsum.photos/201',
    status: 'active',
    tags: ['Cliente VIP', 'Suporte'],
    lastSeen: 'Ontem, 15:45',
    email: 'carlos@techsolutions.com.br',
    company: 'Tech Solutions',
    pipelineStage: 'won',
    dealValue: 50000,
    notes: 'Conta Key Account. Prioridade no suporte técnico.'
  },
  {
    id: 'c3',
    name: 'Mariana Costa',
    phoneNumber: '+55 21 97777-9012',
    avatar: 'https://picsum.photos/202',
    status: 'active',
    tags: ['Novo Lead'],
    lastSeen: 'Hoje, 09:00',
    email: 'mariana.costa@freelance.com',
    company: 'Freelancer',
    pipelineStage: 'new',
    dealValue: 2500
  },
  {
    id: 'c4',
    name: 'João Mendes',
    phoneNumber: '+55 31 96666-3456',
    avatar: 'https://picsum.photos/203',
    status: 'archived',
    tags: ['Ex-Cliente'],
    lastSeen: 'Semana passada',
    company: 'Mendes Engenharia',
    pipelineStage: 'lost',
    dealValue: 0,
    notes: 'Cliente cancelou por contenção de custos.'
  },
  {
    id: 'c5',
    name: 'Fernanda Lima',
    phoneNumber: '+55 41 95555-7890',
    avatar: 'https://picsum.photos/204',
    status: 'active',
    tags: ['Negociação'],
    lastSeen: 'Hoje, 14:20',
    company: 'Lima Advocacia',
    pipelineStage: 'negotiation',
    dealValue: 8000
  },
  {
    id: 'c6',
    name: 'Roberto Santos',
    phoneNumber: '+55 51 94444-1234',
    avatar: 'https://picsum.photos/205',
    status: 'active',
    tags: ['Qualificado'],
    lastSeen: 'Ontem, 18:00',
    company: 'RS Consultoria',
    pipelineStage: 'qualified',
    dealValue: 12000
  }
];

export const MOCK_CHATS: Chat[] = [
  {
    id: 'chat1',
    contactId: 'c1',
    unreadCount: 2,
    lastMessage: {
      id: 'm10',
      chatId: 'chat1',
      senderId: 'c1',
      content: 'Gostaria de saber mais sobre os planos Enterprise.',
      timestamp: '10:30',
      status: 'read',
      type: 'text'
    },
    pinned: true
  },
  {
    id: 'chat2',
    contactId: 'c2',
    unreadCount: 0,
    lastMessage: {
      id: 'm20',
      chatId: 'chat2',
      senderId: 'me',
      content: 'Certo, abriremos um chamado técnico para você.',
      timestamp: 'Ontem',
      status: 'read',
      type: 'text'
    },
    pinned: false
  },
  {
    id: 'chat3',
    contactId: 'c3',
    unreadCount: 1,
    lastMessage: {
      id: 'm30',
      chatId: 'chat3',
      senderId: 'c3',
      content: 'Olá! Vocês têm integração com Notion?',
      timestamp: '09:00',
      status: 'delivered',
      type: 'text'
    },
    pinned: false
  }
];

export const MOCK_MESSAGES: Record<string, Message[]> = {
  'chat1': [
    { id: 'm1', chatId: 'chat1', senderId: 'me', content: 'Olá Ana, tudo bem? Como posso ajudar?', timestamp: '10:00', status: 'read', type: 'text' },
    { id: 'm2', chatId: 'chat1', senderId: 'c1', content: 'Oi! Tudo ótimo. Vi o site de vocês.', timestamp: '10:05', status: 'read', type: 'text' },
    { id: 'm3', chatId: 'chat1', senderId: 'c1', content: 'Estou buscando uma solução de CRM.', timestamp: '10:06', status: 'read', type: 'text' },
    { id: 'm4', chatId: 'chat1', senderId: 'me', content: 'Perfeito! Temos planos para todos os tamanhos.', timestamp: '10:10', status: 'read', type: 'text' },
    { id: 'm10', chatId: 'chat1', senderId: 'c1', content: 'Gostaria de saber mais sobre os planos Enterprise.', timestamp: '10:30', status: 'read', type: 'text' }
  ],
  'chat2': [
    { id: 'm11', chatId: 'chat2', senderId: 'c2', content: 'Estou com problema na API.', timestamp: 'Ontem 14:00', status: 'read', type: 'text' },
    { id: 'm12', chatId: 'chat2', senderId: 'me', content: 'Qual o erro que aparece?', timestamp: 'Ontem 14:10', status: 'read', type: 'text' },
    { id: 'm13', chatId: 'chat2', senderId: 'c2', content: 'Erro 500 no endpoint de cadastro.', timestamp: 'Ontem 14:15', status: 'read', type: 'text' },
    { id: 'm20', chatId: 'chat2', senderId: 'me', content: 'Certo, abriremos um chamado técnico para você.', timestamp: 'Ontem 15:45', status: 'read', type: 'text' }
  ],
  'chat3': [
    { id: 'm30', chatId: 'chat3', senderId: 'c3', content: 'Olá! Vocês têm integração com Notion?', timestamp: '09:00', status: 'delivered', type: 'text' }
  ]
};